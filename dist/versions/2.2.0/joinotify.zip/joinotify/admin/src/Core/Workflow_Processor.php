<?php

namespace MeuMouse\Joinotify\Core;

use MeuMouse\Joinotify\Admin\Admin;
use MeuMouse\Joinotify\Api\Controller;
use MeuMouse\Joinotify\Api\Transport;
use MeuMouse\Joinotify\Cron\Schedule;
use MeuMouse\Joinotify\Builder\Attachments;
use MeuMouse\Joinotify\Validations\Conditions;
use MeuMouse\Joinotify\Integrations\Woocommerce;
use MeuMouse\Joinotify\AI\AI_Manager;
use MeuMouse\Joinotify\AI\AI_Request;
use MeuMouse\Joinotify\Notifications\Channel_Manager;
use MeuMouse\Joinotify\Notifications\Notification_Message;

// Exit if accessed directly.
defined('ABSPATH') || exit;

/**
 * Process workflow content and send messages on fire hooks
 * 
 * @since 1.0.0
 * @version 1.4.7
 * @package MeuMouse\Joinotify\Core
 * @author MeuMouse.com
 */
class Workflow_Processor {

    /**
     * Whether a stop_funnel action has halted the current execution segment.
     *
     * Reset at the start of every workflow run and every scheduled segment, so
     * stopping one funnel never leaks into the next workflow processed on the
     * same request.
     *
     * @since 2.0.0
     * @var bool
     */
    private static $funnel_stopped = false;


    /**
     * Flag the current execution segment as stopped.
     *
     * Used as the handler for the `stop_funnel` action so that no subsequent
     * action in the funnel (linear, branch or scheduled) is dispatched.
     *
     * @since 2.0.0
     * @return bool
     */
    public static function stop_funnel() {
        self::$funnel_stopped = true;

        return true;
    }


    /**
     * Returns published posts whose trigger fires on a specific hook.
     *
     * Primary lookup uses the dedicated, indexed meta key `_joinotify_trigger_hook`
     * written on save (see Admin\Builder\Registry). For workflows that have not yet
     * been migrated/saved since the upgrade, a `LIKE` fallback over the serialized
     * content is kept so no live workflow is missed. The migration on
     * `Joinotify/Upgraded` backfills the index, after which only the exact match runs.
     *
     * @since 1.0.0
     * @version 2.0.0
     * @param string $hook_name | Name of the hook to search for
     * @return array | List of posts that have the specified hook
     */
    public static function get_workflows_by_hook( $hook_name ) {
        $args = array(
            'post_type' => 'joinotify-workflow',
            'post_status' => 'publish',
            'numberposts' => -1,
            'meta_query' => array(
                'relation' => 'OR',
                // Fast path: exact match on the indexed trigger-hook meta.
                array(
                    'key' => '_joinotify_trigger_hook',
                    'value' => $hook_name,
                    'compare' => '=',
                ),
                // Legacy fallback: workflow not migrated yet (no index meta) -> content LIKE.
                array(
                    'relation' => 'AND',
                    array(
                        'key' => '_joinotify_trigger_hook',
                        'compare' => 'NOT EXISTS',
                    ),
                    array(
                        'key' => 'joinotify_workflow_content',
                        'value' => $hook_name,
                        'compare' => 'LIKE',
                    ),
                ),
            ),
        );

        // Returns the posts found
        return get_posts( $args );
    }


    /**
     * Process workflow for each called hook
     * 
     * @since 1.0.0
     * @version 1.4.7
     * @param array $payload | Payload data
     * @return void
     */
    public static function process_workflows( $payload ) {
        $hook = $payload['hook'];
        $workflows = self::get_workflows_by_hook( $hook );

        /**
         * Process workflows hook
         * 
         * @since 1.2.0
         * @param string $hook | Hook for call actions
         * @param array $payload | Payload data
         * @param array $workflows | Array of workflows
         */
        do_action( 'Joinotify/Workflow_Processor/Process_Workflows', $hook, $payload, $workflows );

        if ( defined('JOINOTIFY_DEBUG_MODE') && JOINOTIFY_DEBUG_MODE ) {
            Logger::register_log( 'Function process_workflows() fired' );
            Logger::register_log( 'hook: ' . print_r( $hook, true ) );
            Logger::register_log( 'payload: ' . print_r( $payload, true ) );
        }

        if ( empty( $workflows ) ) {
            return;
        }

        // loop through workflows
        foreach ( $workflows as $workflow ) {
            $workflow_content = Helpers::get_workflow_content_meta( $workflow->ID );

            if ( ! empty( $workflow_content ) && is_array( $workflow_content ) ) {
                $post_id = $workflow->ID; // for get workflow content

                self::process_workflow_content( $workflow_content, $post_id, $payload );
            }
        }
    }


    /**
     * Process workflow content
     * 
     * @since 1.0.0
     * @version 1.4.7
     * @param array $workflow_content | Workflow content
     * @param int $post_id | Post ID
     * @param array $payload | Payload data
     * @return void
     */
    public static function process_workflow_content( $workflow_content, $post_id, $payload ) {
        // Start every workflow with a clean stop flag.
        self::$funnel_stopped = false;

        if ( JOINOTIFY_DEV_MODE ) {
            error_log( 'Function process_workflow_content() fired' );
            error_log( 'Param $workflow_content: ' . print_r( $workflow_content, true ) );
            error_log( 'Param $post_id: ' . print_r( $post_id, true ) );
            error_log( 'Param $payload: ' . print_r( $payload, true ) );
        }

        /**
         * Before process Joinotify workflows
         *
         * @since 1.2.0
         * @param array $workflow_content | Workflow content
         * @param int $post_id | Post ID
         * @param array $payload | Payload data
         */
        do_action( 'Joinotify/Workflow_Processor/Process_Workflow_Content', $workflow_content, $post_id, $payload );

        if ( ! is_array( $workflow_content ) ) {
            return;
        }

        // Rebuild the execution order/nesting from the authoritative wiring
        // (connection_from) so a branch whose stored array drifted out of sync
        // (e.g. a delay saved after the message it should precede) still runs in
        // the real connected order. No-op for already well-formed content and a
        // safe fallback for legacy nodes without connection_from.
        $workflow_content = self::reorder_by_connections( $workflow_content );

        // resolve the trigger node (guard against malformed/trigger-less content)
        $trigger_data = self::get_trigger_node( $workflow_content );

        if ( empty( $trigger_data ) ) {
            Logger::register_log( sprintf( 'Workflow %d skipped: no trigger node found.', $post_id ), 'WARNING' );

            return;
        }

        // only run when this trigger actually matches the runtime payload
        if ( ! self::matches_trigger( $trigger_data, $payload ) ) {
            return;
        }

        // Carry the trigger slug on the payload so the placeholder resolver can scope the
        // catalog the same way the builder does. Integrations only set 'hook', so without
        // this Placeholders::get_placeholders_list() takes the "no trigger" branch and
        // returns the whole integration group, resolving tokens that do not belong to this
        // trigger. The gate above guarantees the slug equals the fired hook.
        /**
         * Filter whether the placeholder catalog is scoped to the trigger at runtime.
         *
         * Third-party placeholders registered with a "triggers" list that does not match
         * their dispatched slug used to resolve anyway, because the catalog was never
         * filtered. Returning false restores that behaviour for a single workflow.
         *
         * @since 2.1.0
         * @param bool  $scope        Whether to carry the trigger slug on the payload.
         * @param array $trigger_data Trigger node ({id,type,data}).
         * @param array $payload      Runtime trigger payload.
         */
        $scope_placeholders = apply_filters( 'Joinotify/Workflow_Processor/Scope_Placeholders_By_Trigger', true, $trigger_data, $payload );

        if ( $scope_placeholders && ! isset( $payload['trigger'] ) && isset( $trigger_data['data']['trigger'] ) ) {
            $payload['trigger'] = (string) $trigger_data['data']['trigger'];
        }

        // top-level linear actions (siblings); conditions carry their own branches
        $workflow_actions = array_values( array_filter( $workflow_content, function ( $item ) {
            return isset( $item['type'] ) && $item['type'] !== 'trigger';
        }));

        // per-instance idempotency state (null = stateless; cron continuation handles resume)
        $state_key = self::get_state_meta_key( $payload );
        $state = self::load_state( $post_id, $state_key );

        // Always walk from the top; processed_actions skips leaves already executed
        // for the same instance, so re-firing a trigger never double-sends.
        $state['pending_actions'] = $workflow_actions;
        self::persist_state( $post_id, $state_key, $state );

        // run the flow through the unified walker
        self::run_segment( $workflow_actions, $post_id, $payload, $state, $state_key );
    }


    /**
     * Extract the (single) trigger node from a workflow content array.
     *
     * @since 2.0.0
     * @param array $workflow_content | Workflow content
     * @return array Trigger node, or empty array when absent.
     */
    protected static function get_trigger_node( $workflow_content ) {
        foreach ( $workflow_content as $item ) {
            if ( isset( $item['type'] ) && $item['type'] === 'trigger' ) {
                return $item;
            }
        }

        return array();
    }


    /**
     * Rebuild a workflow's execution order and branch nesting from the wiring
     * stored on each node (`data.connection_from`).
     *
     * The visual builder keeps a node's real connection (source node + output
     * handle) in `connection_from`, which is authoritative. The nested
     * `children`/branch arrays are a derived convenience that can drift out of
     * sync after edits (reordering, inserting a delay before a nested condition,
     * duplicating nodes), leaving a branch whose array order no longer matches the
     * drawn flow. When that happens the queue walker runs nodes in the wrong
     * order — e.g. sending a message before the delay that should precede it.
     *
     * Reconstruction is two-phase: (1) follow the wiring from the trigger outward
     * to rebuild the connected skeleton in true execution order, nesting each
     * condition's branches; (2) graft any node that carries no wiring (typically a
     * branch leaf) back into the exact container it was stored in, preserving its
     * original relative order. Content with no wiring at all therefore rebuilds
     * identically to what was stored (safe no-op). If any node cannot be placed
     * exactly once, the original is returned untouched.
     *
     * @since 2.0.0
     * @param array $workflow_content | Stored workflow content
     * @return array Reordered content, or the original when it cannot be rebuilt safely.
     */
    protected static function reorder_by_connections( array $workflow_content ) {
        $triggers = array();
        $non_triggers = array();

        foreach ( $workflow_content as $node ) {
            if ( isset( $node['type'] ) && $node['type'] === 'trigger' ) {
                $triggers[] = $node;
            } else {
                $non_triggers[] = $node;
            }
        }

        // Without a trigger to anchor the walk there is nothing to rebuild from.
        if ( empty( $triggers ) ) {
            return $workflow_content;
        }

        // Flatten every non-trigger node (at any depth) into a pool keyed by id,
        // remembering each node's original container (parent + branch) and order.
        $pool = array();
        $meta = array();
        $order = array();
        self::collect_flow_nodes( $non_triggers, '', '', $pool, $meta, $order );

        $used = array();
        $rebuilt = array();

        // Each trigger is a root; its connected chain (plus any un-wired top-level
        // nodes grafted home) follows as top-level siblings.
        foreach ( $triggers as $trigger ) {
            $rebuilt[] = $trigger;
            $trigger_id = isset( $trigger['id'] ) ? (string) $trigger['id'] : '';

            foreach ( self::build_branch( $trigger_id, 'output', '', '', $pool, $meta, $order, $used ) as $child ) {
                $rebuilt[] = $child;
            }
        }

        // Every pooled node must be placed exactly once; otherwise keep the stored
        // structure rather than risk dropping or duplicating an action.
        if ( count( $used ) !== count( $pool ) ) {
            return $workflow_content;
        }

        return $rebuilt;
    }


    /**
     * Flatten workflow nodes (condition branches and any linear children, at any
     * depth) into a flat pool keyed by node id, recording each node's original
     * container (parent id + branch key) and pre-order position so the rebuild can
     * graft un-wired nodes back where they were stored.
     *
     * @since 2.0.0
     * @param array $nodes | Node list to flatten
     * @param string $parent_id | Id of the containing condition ('' at top level)
     * @param string $branch_key | 'action_true' / 'action_false' ('' at top level)
     * @param array $pool | Pool accumulator (by ref), keyed by node id
     * @param array $meta | Original-home accumulator (by ref): id => {parent,branch}
     * @param array $order | Pre-order id list (by ref) for stable grafting
     * @return void
     */
    protected static function collect_flow_nodes( $nodes, $parent_id, $branch_key, array &$pool, array &$meta, array &$order ) {
        if ( ! is_array( $nodes ) ) {
            return;
        }

        foreach ( $nodes as $node ) {
            if ( ! is_array( $node ) || ! isset( $node['id'] ) ) {
                continue;
            }

            $id = (string) $node['id'];
            $children = $node['children'] ?? array();
            $branches = $node['branches'] ?? array();

            // strip structural containers; the rebuild reattaches them
            unset( $node['children'], $node['branches'] );
            $pool[ $id ] = $node;
            $meta[ $id ] = array( 'parent' => (string) $parent_id, 'branch' => (string) $branch_key );
            $order[] = $id;

            // branch containers (condition's true/false, loop's body) can live under
            // children (object form) or branches; a single source holds every branch key
            $branch_source = null;

            if ( is_array( $children ) && ( isset( $children['action_true'] ) || isset( $children['action_false'] ) || isset( $children['action_loop'] ) ) ) {
                $branch_source = $children;
            } elseif ( is_array( $branches ) && ( isset( $branches['action_true'] ) || isset( $branches['action_false'] ) || isset( $branches['action_loop'] ) ) ) {
                $branch_source = $branches;
            }

            if ( null !== $branch_source ) {
                self::collect_flow_nodes( $branch_source['action_true'] ?? array(), $id, 'action_true', $pool, $meta, $order );
                self::collect_flow_nodes( $branch_source['action_false'] ?? array(), $id, 'action_false', $pool, $meta, $order );
                self::collect_flow_nodes( $branch_source['action_loop'] ?? array(), $id, 'action_loop', $pool, $meta, $order );
            } elseif ( is_array( $children ) ) {
                // Linear children (rare in this model); keep them tied to this exact
                // parent so they can only ever graft back here.
                self::collect_flow_nodes( $children, $id, 'children', $pool, $meta, $order );
            }
        }
    }


    /**
     * Build one container (top-level list or a condition branch) in execution order.
     *
     * First it follows the wiring from ($wire_source, $wire_handle), appending each
     * connected node in turn (recursing into conditions via materialize_node()).
     * Then it grafts back any not-yet-placed node whose original home is exactly
     * ($home_parent, $home_branch) — i.e. leaves that carry no wiring — keeping
     * their stored relative order. Nodes are consumed from the shared pool (tracked
     * in $used) so each is placed exactly once.
     *
     * @since 2.0.0
     * @param string $wire_source | Id whose output handle we follow for the chain
     * @param string $wire_handle | Output handle to follow ('output' / 'true' / 'false')
     * @param string $home_parent | Original parent id used to graft un-wired nodes
     * @param string $home_branch | Original branch key used to graft un-wired nodes
     * @param array $pool | Flat pool of candidate nodes, keyed by id
     * @param array $meta | Original-home map: id => {parent,branch}
     * @param array $order | Pre-order id list for stable grafting
     * @param array $used | Ids already placed (by ref)
     * @return array Ordered container (conditions carry nested `children`).
     */
    protected static function build_branch( $wire_source, $wire_handle, $home_parent, $home_branch, array &$pool, array &$meta, array &$order, array &$used ) {
        $result = array();

        // 1) connected chain: follow the wiring from the current output handle.
        $current_source = (string) $wire_source;
        $current_handle = (string) $wire_handle;

        while ( true ) {
            $next_id = null;

            foreach ( $pool as $id => $node ) {
                if ( isset( $used[ $id ] ) ) {
                    continue;
                }

                $from = $node['data']['connection_from'] ?? array();
                $from_source = isset( $from['source_id'] ) ? (string) $from['source_id'] : '';
                $from_handle = isset( $from['source_handle'] ) ? (string) $from['source_handle'] : 'output';

                if ( '' !== $from_source && $from_source === $current_source && $from_handle === $current_handle ) {
                    $next_id = $id;

                    break;
                }
            }

            if ( null === $next_id ) {
                break;
            }

            $result[] = self::materialize_node( $next_id, $pool, $meta, $order, $used );
            $current_source = $next_id;
            $current_handle = 'output';
        }

        // 2) graft un-wired nodes stored directly in this container, in order.
        foreach ( $order as $id ) {
            if ( isset( $used[ $id ] ) ) {
                continue;
            }

            if ( ( $meta[ $id ]['parent'] ?? '' ) === (string) $home_parent && ( $meta[ $id ]['branch'] ?? '' ) === (string) $home_branch ) {
                $result[] = self::materialize_node( $id, $pool, $meta, $order, $used );
            }
        }

        return $result;
    }


    /**
     * Place a single node into the rebuilt tree, nesting its branches when it is a
     * condition (each branch built via build_branch(), which mixes the connected
     * chain with any un-wired leaves grafted home).
     *
     * @since 2.0.0
     * @param string $id | Node id to materialize (must exist in $pool)
     * @param array $pool | Flat pool of candidate nodes, keyed by id
     * @param array $meta | Original-home map: id => {parent,branch}
     * @param array $order | Pre-order id list for stable grafting
     * @param array $used | Ids already placed (by ref)
     * @return array The node with its `children` rebuilt.
     */
    protected static function materialize_node( $id, array &$pool, array &$meta, array &$order, array &$used ) {
        $used[ $id ] = true;
        $node = $pool[ $id ];

        // conditions nest their true/false branches; loops nest their single body
        // branch (and still continue after the loop via their own 'output' handle);
        // linear nodes continue via siblings
        $node_action = $node['data']['action'] ?? '';

        if ( $node_action === 'condition' ) {
            $node['children'] = array(
                'action_true' => self::build_branch( $id, 'true', $id, 'action_true', $pool, $meta, $order, $used ),
                'action_false' => self::build_branch( $id, 'false', $id, 'action_false', $pool, $meta, $order, $used ),
            );
        } elseif ( in_array( $node_action, self::get_looping_action_slugs(), true ) ) {
            $node['children'] = array(
                'action_loop' => self::build_branch( $id, 'loop', $id, 'action_loop', $pool, $meta, $order, $used ),
            );
        } else {
            $node['children'] = array();
        }

        return $node;
    }


    /**
     * Action slugs treated as "looping": they nest their body under the
     * 'action_loop' branch and are expanded once per collection item by
     * run_segment().
     *
     * @since 2.1.1
     * @return array<int,string>
     */
    protected static function get_looping_action_slugs() {
        /**
         * Filter the action slugs treated as looping actions.
         *
         * A looping action nests its body under children['action_loop'] and is
         * unrolled once per resolved collection item. Third parties can register a
         * custom looping slug (reusing the same body shape and the Resolve_Loop_Items
         * filter to provide the collection) by adding it here.
         *
         * @since 2.1.1
         * @param array $slugs Looping action slugs.
         */
        $slugs = apply_filters( 'Joinotify/Workflow_Processor/Looping_Actions', array( 'loop' ) );

        return is_array( $slugs ) ? $slugs : array( 'loop' );
    }


    /**
     * Resolve the collection a loop node iterates over into a list of flat,
     * serializable items (so each item survives a time delay inside the body).
     *
     * @since 2.1.1
     * @param array $node_data | Loop node data (loop_source, loop_list, ...)
     * @param array $payload | Runtime payload
     * @return array<int,array<string,mixed>>
     */
    protected static function resolve_loop_items( $node_data, $payload ) {
        $source = isset( $node_data['loop_source'] ) ? sanitize_key( (string) $node_data['loop_source'] ) : 'order_downloads';
        $items = array();

        if ( 'order_downloads' === $source ) {
            $items = self::resolve_loop_order_downloads( $payload );
        } elseif ( 'order_items' === $source ) {
            $items = self::resolve_loop_order_items( $payload );
        } elseif ( 'placeholder_list' === $source ) {
            $items = self::resolve_loop_placeholder_list( $node_data, $payload );
        }

        // optional cap so a very large collection cannot flood the queue
        $max = isset( $node_data['loop_max_items'] ) ? absint( $node_data['loop_max_items'] ) : 0;

        if ( $max > 0 && count( $items ) > $max ) {
            $items = array_slice( $items, 0, $max );
        }

        /**
         * Filter the resolved items a loop node iterates over.
         *
         * Lets third parties provide the collection for a custom loop source (or
         * refine the built-in ones). Each item should be a flat array of scalars;
         * the 'value' key is used as the default {{ loop_value }} replacement.
         *
         * @since 2.1.1
         * @param array $items     Normalized items.
         * @param array $node_data Loop node data.
         * @param array $payload   Runtime payload.
         */
        $items = apply_filters( 'Joinotify/Workflow_Processor/Resolve_Loop_Items', $items, $node_data, $payload );

        return is_array( $items ) ? array_values( array_filter( $items, 'is_array' ) ) : array();
    }


    /**
     * Resolve the downloadable files of the payload order into loop items.
     *
     * @since 2.1.1
     * @param array $payload | Runtime payload
     * @return array<int,array<string,mixed>>
     */
    protected static function resolve_loop_order_downloads( $payload ) {
        $order = self::get_loop_order( $payload );

        if ( ! $order ) {
            return array();
        }

        $items = array();

        foreach ( Woocommerce::get_downloadable_items( $order ) as $download ) {
            $file = isset( $download['file'] ) && is_array( $download['file'] ) ? $download['file'] : array();
            $name = (string) ( $download['download_name'] ?? ( $file['name'] ?? '' ) );

            $items[] = array(
                'type' => 'download',
                'value' => '' !== $name ? $name : (string) ( $download['product_name'] ?? '' ),
                'file_name' => (string) ( $file['name'] ?? '' ),
                'file_ref' => (string) ( $file['file'] ?? '' ),
                'download_url' => (string) ( $download['download_url'] ?? '' ),
                'product_id' => absint( $download['product_id'] ?? 0 ),
                'product_name' => (string) ( $download['product_name'] ?? '' ),
            );
        }

        return $items;
    }


    /**
     * Resolve the purchased line items of the payload order into loop items.
     *
     * @since 2.1.1
     * @param array $payload | Runtime payload
     * @return array<int,array<string,mixed>>
     */
    protected static function resolve_loop_order_items( $payload ) {
        $order = self::get_loop_order( $payload );

        if ( ! $order || ! method_exists( $order, 'get_items' ) ) {
            return array();
        }

        $items = array();

        foreach ( $order->get_items() as $line ) {
            if ( ! is_object( $line ) || ! method_exists( $line, 'get_name' ) ) {
                continue;
            }

            $items[] = array(
                'type' => 'order_item',
                'value' => (string) $line->get_name(),
                'name' => (string) $line->get_name(),
                'quantity' => method_exists( $line, 'get_quantity' ) ? (int) $line->get_quantity() : 1,
                'product_id' => method_exists( $line, 'get_product_id' ) ? absint( $line->get_product_id() ) : 0,
            );
        }

        return $items;
    }


    /**
     * Resolve a delimited placeholder value into loop items, one per entry.
     *
     * @since 2.1.1
     * @param array $node_data | Loop node data (loop_list, loop_delimiter)
     * @param array $payload | Runtime payload
     * @return array<int,array<string,mixed>>
     */
    protected static function resolve_loop_placeholder_list( $node_data, $payload ) {
        $raw = joinotify_prepare_message( (string) ( $node_data['loop_list'] ?? '' ), $payload );

        if ( '' === trim( $raw ) ) {
            return array();
        }

        $delimiter = isset( $node_data['loop_delimiter'] ) && '' !== (string) $node_data['loop_delimiter']
            ? (string) $node_data['loop_delimiter']
            : "\n";

        // normalize CRLF so a newline delimiter behaves the same on every platform
        $raw = str_replace( array( "\r\n", "\r" ), "\n", $raw );
        $items = array();

        foreach ( explode( $delimiter, $raw ) as $part ) {
            $value = trim( $part );

            if ( '' === $value ) {
                continue;
            }

            $items[] = array(
                'type' => 'list',
                'value' => $value,
            );
        }

        return $items;
    }


    /**
     * Resolve the order of a loop payload, following a refund to its parent order.
     *
     * @since 2.1.1
     * @param array $payload | Runtime payload
     * @return \WC_Order|null
     */
    protected static function get_loop_order( $payload ) {
        if ( ! isset( $payload['order_id'] ) || ! function_exists('wc_get_order') ) {
            return null;
        }

        $order = wc_get_order( $payload['order_id'] );

        if ( $order instanceof \WC_Order_Refund ) {
            $order = wc_get_order( $order->get_parent_id() );
        }

        return $order ?: null;
    }


    /**
     * Build the unrolled queue for a loop: for each item, a synthetic context node
     * (which pins the item onto the payload) followed by a deep copy of the body,
     * every node id rewritten to a per-iteration unique id so the idempotency layer
     * never skips a repeated body node.
     *
     * @since 2.1.1
     * @param array $items | Resolved loop items
     * @param array $body | Loop body nodes (children['action_loop'])
     * @param string $loop_id | Id of the loop node (namespaces the synthetic ids)
     * @return array<int,array<string,mixed>>
     */
    protected static function build_loop_queue( $items, $body, $loop_id ) {
        $queue = array();
        $count = count( $items );

        foreach ( array_values( $items ) as $index => $item ) {
            $queue[] = array(
                'id' => $loop_id . '::ctx::' . $index,
                'type' => 'action',
                'data' => array(
                    'action' => 'loop_set_context',
                    'loop_context' => array(
                        'item' => is_array( $item ) ? $item : array( 'value' => $item ),
                        'index' => $index,
                        'number' => $index + 1,
                        'count' => $count,
                    ),
                ),
                'children' => array(),
            );

            foreach ( $body as $body_node ) {
                if ( is_array( $body_node ) ) {
                    $queue[] = self::clone_loop_node( $body_node, $loop_id, $index );
                }
            }
        }

        return $queue;
    }


    /**
     * Deep-copy a loop body node for one iteration, rewriting its id (and those of
     * all descendants) so repeated iterations never collide in processed_actions.
     *
     * @since 2.1.1
     * @param array $node | Body node to clone
     * @param string $loop_id | Loop node id
     * @param int $index | Iteration index
     * @return array<string,mixed>
     */
    protected static function clone_loop_node( $node, $loop_id, $index ) {
        $clone = $node;

        if ( isset( $node['id'] ) ) {
            $clone['id'] = $loop_id . '::' . $index . '::' . $node['id'];
        }

        if ( isset( $node['children'] ) && is_array( $node['children'] ) ) {
            $children = $node['children'];

            // branch container (condition/loop) keeps its keys; linear children are a list
            if ( isset( $children['action_true'] ) || isset( $children['action_false'] ) || isset( $children['action_loop'] ) ) {
                $rebuilt = array();

                foreach ( $children as $branch_key => $branch_nodes ) {
                    $rebuilt[ $branch_key ] = is_array( $branch_nodes )
                        ? array_map( function( $child ) use ( $loop_id, $index ) {
                            return is_array( $child ) ? self::clone_loop_node( $child, $loop_id, $index ) : $child;
                        }, $branch_nodes )
                        : $branch_nodes;
                }

                $clone['children'] = $rebuilt;
            } else {
                $clone['children'] = array_map( function( $child ) use ( $loop_id, $index ) {
                    return is_array( $child ) ? self::clone_loop_node( $child, $loop_id, $index ) : $child;
                }, $children );
            }
        }

        return $clone;
    }


    /**
     * Pin the current loop item onto the payload so the iteration's body resolves
     * {{ loop_* }} tokens and the loop_item attachment source against it.
     *
     * @since 2.1.1
     * @param array $action_data | Synthetic loop_set_context node data
     * @param array $payload | Runtime payload (by reference)
     * @return bool
     */
    protected static function apply_loop_context( $action_data, &$payload ) {
        $payload['loop'] = isset( $action_data['loop_context'] ) && is_array( $action_data['loop_context'] )
            ? $action_data['loop_context']
            : array();

        return true;
    }


    /**
     * Decide whether a workflow's trigger matches the runtime payload.
     *
     * The built-in integrations (WooCommerce/WPForms/WordPress/Elementor) declare
     * their matching rules here as the default. Third parties can refine or replace
     * the decision for their own triggers through the filter below, keeping the
     * runtime matching extensible instead of hardcoded per integration.
     *
     * @since 2.0.0
     * @param array $trigger_data | Trigger node ({id,type,data})
     * @param array $payload | Runtime trigger payload
     * @return bool
     */
    protected static function matches_trigger( $trigger_data, $payload ) {
        $integration = $payload['integration'] ?? '';
        $settings = $trigger_data['data']['settings'] ?? array();

        $trigger_hook = isset( $trigger_data['data']['trigger'] ) ? (string) $trigger_data['data']['trigger'] : '';
        $payload_hook = isset( $payload['hook'] ) ? (string) $payload['hook'] : '';

        // Authoritative gate: the workflow only runs when its trigger node matches
        // the fired hook. This makes the _joinotify_trigger_hook index a pure
        // optimization and prevents any content-LIKE false positive from dispatching.
        $match = ( '' !== $trigger_hook && $trigger_hook === $payload_hook );

        if ( $integration === 'woocommerce' ) {
            if ( isset( $payload['order_id'] ) ) {
                $order = wc_get_order( $payload['order_id'] );

                if ( ! $order ) {
                    $match = false;
                } elseif ( isset( $payload['hook'] ) && $payload['hook'] === 'woocommerce_order_status_changed' ) {
                    $order_status = str_replace( 'wc-', '', $order->get_status() );
                    $trigger_order_status = isset( $settings['order_status'] ) && is_scalar( $settings['order_status'] )
                        ? str_replace( 'wc-', '', (string) $settings['order_status'] )
                        : '';

                    // "none" => any status
                    if ( $trigger_order_status !== 'none' && $trigger_order_status !== $order_status ) {
                        $match = false;
                    }
                } elseif ( isset( $payload['hook'] ) && in_array( $payload['hook'], array( 'woocommerce_grant_product_download_permissions', 'woocommerce_download_product' ), true ) ) {
                    $trigger_product_id = isset( $settings['product_id'] ) && is_scalar( $settings['product_id'] )
                        ? (string) $settings['product_id']
                        : '';

                    // "none" or an unset filter => any digital product. Only ever narrows the
                    // decision, so it can never resurrect a match the hook gate already denied.
                    if ( '' !== $trigger_product_id && 'none' !== $trigger_product_id
                        && ! self::payload_matches_downloadable_product( $order, $payload, $trigger_product_id )
                    ) {
                        $match = false;
                    }
                }
            }
        } elseif ( $integration === 'wpforms' ) {
            if ( ! isset( $payload['id'] ) || (int) $payload['id'] !== absint( $settings['form_id'] ?? 0 ) ) {
                $match = false;
            }
        } elseif ( $integration === 'wordpress' ) {
            if ( isset( $payload['hook'], $payload['post_id'], $payload['post_status'], $settings['post_status'] )
                && ( $payload['hook'] === 'change_post_status' || $payload['hook'] === 'transition_post_status' )
                && get_post_type( $payload['post_id'] ) === 'post'
            ) {
                $trigger_post_status = $settings['post_status'];

                if ( $trigger_post_status !== 'none' && $payload['post_status'] !== $trigger_post_status ) {
                    $match = false;
                }
            }
        } elseif ( $integration === 'elementor' ) {
            $trigger_form_id = $settings['form_id'] ?? '';

            if ( empty( $trigger_form_id ) || (string) ( $payload['id'] ?? '' ) !== (string) $trigger_form_id ) {
                $match = false;
            }
        }

        /**
         * Filter the trigger matching decision.
         *
         * Lets third-party integrations declare whether their registered trigger
         * should fire for the current payload, without editing the core matcher.
         *
         * @since 2.0.0
         * @param bool  $match        Current match decision from the built-in rules.
         * @param array $trigger_data Trigger node ({id,type,data}).
         * @param array $payload      Runtime trigger payload.
         */
        return (bool) apply_filters( 'Joinotify/Workflow_Processor/Trigger_Matches', $match, $trigger_data, $payload );
    }


    /**
     * Whether the digital delivery payload concerns a specific downloadable product.
     *
     * The "file downloaded" payload names the product directly, while the "access granted"
     * payload only names the order, so the order downloads are scanned in that case.
     *
     * @since 2.1.0
     * @param \WC_Order $order | Order of the payload
     * @param array $payload | Runtime trigger payload
     * @param string $product_id | Product ID configured in the trigger settings
     * @return bool
     */
    protected static function payload_matches_downloadable_product( $order, $payload, $product_id ) {
        $product_id = absint( $product_id );

        if ( ! $product_id ) {
            return false;
        }

        // the download handler already tells us which product was downloaded
        if ( isset( $payload['product_id'] ) ) {
            return absint( $payload['product_id'] ) === $product_id;
        }

        foreach ( Woocommerce::get_downloadable_items( $order ) as $item ) {
            if ( absint( $item['product_id'] ?? 0 ) === $product_id ) {
                return true;
            }
        }

        return false;
    }


    /**
     * Run a list of actions through the unified flow walker.
     *
     * This single engine powers both the initial trigger run and the cron resume.
     * It treats the flow as an ordered queue:
     *   - a `condition` node is evaluated and its chosen branch is prepended to the
     *     queue, so branch actions (and any nested conditions) run in place;
     *   - a `time_delay` node schedules the ENTIRE remaining queue as its
     *     continuation and stops the segment, so nothing after a delay is ever lost,
     *     even when the delay sits inside a condition branch;
     *   - any other (leaf) action is dispatched immediately via handle_action().
     *
     * @since 2.0.0
     * @param array  $queue      Ordered list of action nodes to process.
     * @param int    $post_id    Workflow post ID.
     * @param array  $payload    Runtime payload (passed by reference so dynamic
     *                           placeholders/AI variables propagate to later actions).
     * @param array  $state      Idempotency state (processed_actions/pending_actions), by ref.
     * @param string|null $state_key Post-meta key for persistence, or null when stateless.
     * @return void
     */
    protected static function run_segment( array $queue, $post_id, &$payload, array &$state, $state_key ) {
        /**
         * Action slugs treated as "delaying" — they schedule the remaining queue as a
         * continuation and pause the segment. Defaults to the built-in 'time_delay'.
         * Third parties can register a custom delaying action (reusing the same
         * delay-resolution data shape) by adding their slug here.
         *
         * @since 2.0.0
         * @param array $slugs Delaying action slugs.
         */
        $delaying_actions = apply_filters( 'Joinotify/Workflow_Processor/Delaying_Actions', array( 'time_delay' ) );
        $delaying_actions = is_array( $delaying_actions ) ? $delaying_actions : array( 'time_delay' );

        /**
         * Action slugs treated as "branching" — they evaluate and splice a chosen branch
         * into the queue. Defaults to the built-in 'condition'. Third parties can register
         * a custom branching action (reusing the same condition-evaluation data shape) by
         * adding their slug here.
         *
         * @since 2.0.0
         * @param array $slugs Branching action slugs.
         */
        $branching_actions = apply_filters( 'Joinotify/Workflow_Processor/Branching_Actions', array( 'condition' ) );
        $branching_actions = is_array( $branching_actions ) ? $branching_actions : array( 'condition' );

        // Action slugs treated as "looping": they unroll their body once per collection
        // item into the queue (see get_looping_action_slugs()).
        $looping_actions = self::get_looping_action_slugs();

        while ( ! empty( $queue ) ) {
            // a previous action requested the funnel to stop
            if ( self::$funnel_stopped ) {
                break;
            }

            $node = array_shift( $queue );

            if ( ! is_array( $node ) ) {
                continue;
            }

            $node_id = $node['id'] ?? null;
            $node_data = $node['data'] ?? array();
            $action = $node_data['action'] ?? '';

            // skip leaves already executed for this instance (idempotency)
            if ( $state_key && $node_id && in_array( $node_id, $state['processed_actions'], true ) ) {
                continue;
            }

            // delay: schedule the remaining queue as continuation, then stop here
            if ( in_array( $action, $delaying_actions, true ) ) {
                $delay = Schedule::resolve_delay_seconds( $node_data );

                // the continuation is everything still queued after this delay
                $node['data']['next_actions'] = array_values( $queue );

                self::schedule_continuation( $post_id, $payload, $delay, $node, $state_key );

                // remember what is still pending; the delay node is marked processed
                // only when the continuation actually resumes (process_scheduled_action)
                $state['pending_actions'] = array_values( $queue );
                self::persist_state( $post_id, $state_key, $state );

                return;
            }

            // condition: evaluate and splice the chosen branch into the queue
            if ( in_array( $action, $branching_actions, true ) ) {
                $branch = self::evaluate_condition( $node, $post_id, $payload );
                $queue = array_merge( array_values( $branch ), $queue );

                if ( $node_id ) {
                    $state['processed_actions'][] = $node_id;
                    self::persist_state( $post_id, $state_key, $state );
                }

                continue;
            }

            // loop: unroll the body once per collection item, prefixing each iteration
            // with a synthetic context node that pins the current item onto the payload.
            // This reuses the delay machinery: a time_delay inside the body captures the
            // remaining unrolled iterations as its continuation, and each iteration's
            // context node restores the correct item on resume.
            if ( in_array( $action, $looping_actions, true ) ) {
                $body = $node['children']['action_loop'] ?? array();
                $items = self::resolve_loop_items( $node_data, $payload );
                $unrolled = self::build_loop_queue( $items, is_array( $body ) ? $body : array(), (string) ( $node_id ?? 'loop' ) );

                $queue = array_merge( $unrolled, $queue );

                if ( $node_id ) {
                    $state['processed_actions'][] = $node_id;
                    self::persist_state( $post_id, $state_key, $state );
                }

                continue;
            }

            // leaf action: dispatch immediately
            if ( self::handle_action( $node, $post_id, $payload ) ) {
                if ( $node_id ) {
                    $state['processed_actions'][] = $node_id;
                    self::persist_state( $post_id, $state_key, $state );
                }
            }
        }
    }


    /**
     * Schedule a delayed continuation, guarding against an inactive WP-Cron.
     *
     * @since 2.0.0
     * @param int    $post_id    Workflow post ID.
     * @param array  $payload    Runtime payload (serialized into the cron event).
     * @param int    $delay      Delay in seconds from now.
     * @param array  $node       The time_delay node (carries data.next_actions).
     * @param string|null $state_key Instance state key, used to derive a stable cron key.
     * @return bool
     */
    protected static function schedule_continuation( $post_id, $payload, $delay, $node, $state_key ) {
        // Only warn when there is no reliable scheduler at all: Action Scheduler
        // absent AND WP-Cron inactive.
        if ( ! Schedule::is_action_scheduler_available() && ! Schedule::is_wp_cron_active() ) {
            Logger::register_log(
                sprintf( 'No active scheduler (Action Scheduler unavailable and WP-Cron inactive); scheduled action for workflow %d may not fire on time. Consider a real system cron.', $post_id ),
                'WARNING'
            );
        }

        // a stable key (instance + node) so re-scheduling the same continuation
        // replaces the previous event instead of duplicating it
        $unique_key = ( $state_key ?: 'run' ) . ':' . ( $node['id'] ?? uniqid( 'delay_', true ) );

        return Schedule::schedule_actions( $post_id, $payload, $delay, $node, $unique_key );
    }


    /**
     * Resolve the idempotency state meta key for a payload.
     *
     * Returns null for stateless runs (the cron continuation already carries the
     * remaining work, so resume never needs the DB). Currently persists state only
     * for the opt-in WooCommerce "ignore processed actions" feature, keyed by order.
     * Centralized here so coverage can be extended to other integrations with a
     * stable instance key without touching the engine.
     *
     * @since 2.0.0
     * @param array $payload | Runtime payload
     * @return string|null
     */
    protected static function get_state_meta_key( $payload ) {
        $integration = $payload['integration'] ?? '';
        $state_key = null;

        if ( $integration === 'woocommerce'
            && ! empty( $payload['order_id'] )
            && Admin::get_setting( 'enable_ignore_processed_actions' ) === 'yes'
        ) {
            $state_key = 'joinotify_workflow_state_' . $payload['order_id'];
        }

        /**
         * Filter the idempotency state meta key for a runtime payload.
         *
         * Return a stable, per-instance meta key (e.g. built from user_id/post_id/
         * cart_id) to enable processed/pending dedup for integrations other than
         * the built-in WooCommerce opt-in. Return null (default) to stay stateless;
         * the cron continuation still resumes correctly without it.
         *
         * @since 2.0.0
         * @param string|null $state_key Default state key (null = stateless).
         * @param array       $payload   Runtime payload.
         */
        return apply_filters( 'Joinotify/Workflow_Processor/State_Meta_Key', $state_key, $payload );
    }


    /**
     * Load (or initialize) the idempotency state for a workflow instance.
     *
     * @since 2.0.0
     * @param int $post_id | Workflow post ID
     * @param string|null $state_key | Meta key, or null for a fresh in-memory state
     * @return array
     */
    protected static function load_state( $post_id, $state_key ) {
        $default = array(
            'processed_actions' => array(),
            'pending_actions' => array(),
        );

        if ( ! $state_key ) {
            return $default;
        }

        $state = get_post_meta( $post_id, $state_key, true );

        if ( ! is_array( $state ) ) {
            return $default;
        }

        $state['processed_actions'] = isset( $state['processed_actions'] ) && is_array( $state['processed_actions'] ) ? $state['processed_actions'] : array();
        $state['pending_actions'] = isset( $state['pending_actions'] ) && is_array( $state['pending_actions'] ) ? $state['pending_actions'] : array();

        return $state;
    }


    /**
     * Persist the idempotency state when running with a state key.
     *
     * @since 2.0.0
     * @param int $post_id | Workflow post ID
     * @param string|null $state_key | Meta key, or null to skip persistence
     * @param array $state | State to persist
     * @return void
     */
    protected static function persist_state( $post_id, $state_key, $state ) {
        if ( $state_key ) {
            update_post_meta( $post_id, $state_key, $state );
        }
    }


    /**
     * Handle with workflow actions
     * 
     * @since 1.0.0
     * @version 1.4.7
     * @param array $action | Workflow actions array
     * @param int $post_id | Post ID
     * @param array $payload | Payload data
     * @return bool
     */
    public static function handle_action( $action, $post_id, &$event_data ) {
        $action_data = $action['data'] ?? array();

        if ( empty( $action_data['action'] ) ) {
            return false;
        }

        // Delays are normally owned by run_segment() (which captures the continuation).
        // This branch is a safety net for any direct/legacy call to handle_action():
        // it still schedules with a delay computed at runtime (never the stale,
        // save-time delay_timestamp), preserving any continuation already attached.
        if ( $action_data['action'] === 'time_delay' ) {
            $delay = Schedule::resolve_delay_seconds( $action_data );

            return Schedule::schedule_actions( $post_id, $event_data, $delay, $action );
        }

        // AI smart variable: generate a value and store it on the payload (by reference) so the
        // following actions in this segment can reference it through {{ ai:NAME }}. Handled before
        // the closure map because it must mutate the shared payload, not a captured copy.
        if ( $action_data['action'] === 'dynamic_placeholder' ) {
            return self::execute_dynamic_placeholder( $action_data, $event_data );
        }

        // Loop context: pin the current loop item onto the payload (by reference) so the
        // body actions of this iteration resolve {{ loop_* }} tokens and the loop_item
        // attachment source against it. Handled before the closure map for the same
        // reason as dynamic_placeholder: it must mutate the shared payload.
        if ( $action_data['action'] === 'loop_set_context' ) {
            return self::apply_loop_context( $action_data, $event_data );
        }

        /**
         * Required configuration keys for each built-in action.
         *
         * If any of the listed keys is missing or empty in the action data, the action is
         * silently skipped at runtime (a warning is logged) instead of dispatching with an
         * incomplete configuration and risking a fatal error. Third parties can register
         * requirements for their custom action slugs through this filter.
         *
         * @since 2.0.0
         * @param array $required_config Map of action_slug => array of required data keys.
         * @param array $action          Full action item ({id,type,data,children}).
         * @param int   $post_id         Workflow post ID.
         * @param array $event_data      Runtime trigger payload.
         */
        // The media URL and the attachment list are two ways of providing the same file, so
        // an action carrying attachments must not be skipped for having no URL.
        $media_required_config = empty( $action_data['attachments'] )
            ? array( 'sender', 'receiver', 'media_type', 'media_url' )
            : array( 'sender', 'receiver', 'media_type' );

        $required_config = apply_filters( 'Joinotify/Workflow_Processor/Action_Required_Config', array(
            'send_whatsapp_message_text' => array( 'sender', 'receiver', 'message' ),
            'send_whatsapp_message_media' => $media_required_config,
            'send_telegram_message_text' => array( 'receiver', 'message' ),
            'send_resend_email' => array( 'receiver', 'subject', 'message' ),
            'create_coupon' => array( 'settings' ),
        ), $action, $post_id, $event_data );

        // skip the action when any required configuration is missing, avoiding runtime failures
        if ( isset( $required_config[ $action_data['action'] ] ) ) {
            foreach ( $required_config[ $action_data['action'] ] as $required_key ) {
                if ( self::is_config_value_empty( $action_data[ $required_key ] ?? null ) ) {
                    Logger::register_log( sprintf( 'Skipping action "%s": missing required configuration "%s".', $action_data['action'], $required_key ), 'WARNING' );

                    return false;
                }
            }
        }

        /**
         * Filter for enqueue function callback for each action
         *
         * The map is keyed by action slug; each value is a callable returning bool. Third parties
         * can register a handler for a custom action slug here. The action item, workflow post ID
         * and the runtime event payload are passed as extra arguments so custom closures can run
         * with real data (see Api\Extensions::register_action_handler()).
         *
         * @since 1.0.0
         * @version 1.4.7
         * @param array $actions    Map of action_slug => callable.
         * @param array $action     Full action item ({id,type,data,children}).
         * @param int   $post_id    Workflow post ID.
         * @param array $event_data Runtime trigger payload.
         */
        $actions = apply_filters( 'Joinotify/Workflow_Processor/Handle_Actions', array(
            'condition' => fn() => self::process_condition_action( $action, $post_id, $event_data ),
            'send_whatsapp_message_text' => fn() => self::send_whatsapp_message_text( $action_data, $event_data, $post_id ),
            'send_whatsapp_message_media' => fn() => self::send_whatsapp_message_media( $action_data, $event_data, $post_id ),
            'send_whatsapp_ai_message' => fn() => self::send_whatsapp_ai_message( $action_data, $event_data, $post_id ),
            'send_telegram_message_text' => fn() => self::send_telegram_message_text( $action_data, $event_data, $post_id ),
            'send_resend_email' => fn() => self::send_resend_email( $action_data, $event_data, $post_id ),
            'create_coupon' => fn() => self::execute_wc_coupon_action( $action_data, $event_data, $post_id ),
            'snippet_php' => fn() => self::execute_snippet_php( $action_data['snippet_php'], $event_data ),
            'stop_funnel' => fn() => self::stop_funnel(),
        //  'dynamic_placeholder' => fn() => self::execute_dynamic_placeholder( $action_data, $event_data ),
        ), $action, $post_id, $event_data );

        // check if is action
        if ( ! isset( $actions[ $action_data['action'] ] ) ) {
            return false;
        }

        // return action function processed
        return $actions[ $action_data['action'] ]();
    }


    /**
     * Check whether a configuration value should be treated as missing/empty.
     *
     * Handles the common runtime value shapes: null, empty/whitespace strings and
     * empty arrays all count as "not configured".
     *
     * @since 2.0.0
     * @param mixed $value | Configuration value to check
     * @return bool True when the value is considered empty.
     */
    protected static function is_config_value_empty( $value ) {
        if ( $value === null ) {
            return true;
        }

        if ( is_string( $value ) ) {
            return trim( $value ) === '';
        }

        if ( is_array( $value ) ) {
            return empty( $value );
        }

        return false;
    }


    /**
     * Processes a conditional action within a workflow
     *
     * @since 1.1.0
     * @version 1.4.7
     * @param array $action | Condition action data
     * @param int $post_id | Workflow post ID
     * @param array $payload | Payload context data
     * @return bool Returns true if the action is processed successfully
     */
    public static function process_condition_action( $action, $post_id, $payload ) {
        // Evaluate then run the chosen branch through the unified walker so that
        // delays/nested conditions inside the branch behave consistently. Kept as a
        // backward-compatible entry point; the main flow uses evaluate_condition()
        // directly and splices the branch into its own queue.
        $branch = self::evaluate_condition( $action, $post_id, $payload );

        $state = array(
            'processed_actions' => array(),
            'pending_actions' => array(),
        );

        self::run_segment( array_values( $branch ), $post_id, $payload, $state, null );

        return true;
    }


    /**
     * Evaluate a condition node and return the matching branch's action list.
     *
     * Pure decision: it never executes the branch. The walker prepends the returned
     * list onto its queue so branch actions run in place. Works on a local copy of
     * the payload for the comparison so condition metadata never leaks into the
     * payload seen by later actions.
     *
     * @since 2.0.0
     * @param array $action | Condition node ({id,type,data,children})
     * @param int $post_id | Workflow post ID
     * @param array $payload | Runtime payload (by value)
     * @return array Chosen branch (action_true or action_false), possibly empty.
     */
    protected static function evaluate_condition( $action, $post_id, $payload ) {
        if ( JOINOTIFY_DEV_MODE ) {
            error_log( "Processing condition action: " . print_r( $action, true ) );
            error_log( "Post ID: " . print_r( $post_id, true ) );
            error_log( "Payload: " . print_r( $payload, true ) );
        }

        $action_data = $action['data'] ?? array();

        // No condition configured: fall back to the "false" branch instead of
        // dropping the rest of the flow silently.
        if ( empty( $action_data['condition_content'] ) ) {
            return $action['children']['action_false'] ?? array();
        }

        // Extract condition details
        $get_condition = $action_data['condition_content']['condition'] ?? '';
        $condition_type = $action_data['condition_content']['type'] ?? '';
        $payload['condition_content'] = $action_data['condition_content'] ?? array();
        $condition_value = '';

        if ( isset( $payload['hook'] ) && $payload['hook'] === 'woocommerce_order_status_changed' ) {
            $condition_value = isset( $action_data['condition_content']['value'] ) && is_scalar( $action_data['condition_content']['value'] )
                ? str_replace( 'wc-', '', (string) $action_data['condition_content']['value'] )
                : '';
        } else {
            $condition_value = isset( $action_data['condition_content']['value'] ) && is_scalar( $action_data['condition_content']['value'] )
                ? (string) $action_data['condition_content']['value']
                : '';
        }

        // get meta key for user meta condition
        if ( $get_condition === 'user_meta' ) {
            $payload['condition_content']['meta_key'] = $action_data['condition_content']['meta_key'] ?? '';
        } elseif ( $get_condition === 'field_value' ) {
            $payload['condition_content']['field_id'] = $action_data['condition_content']['field_id'] ?? '';
        }

        // Retrieve the comparison value based on the event data
        $compare_value = Conditions::get_compare_value( $get_condition, $payload );

        // Check if the condition is met
        $condition_met = Conditions::check_condition( $condition_type, $compare_value, $condition_value, $payload );

        // Determine the next actions based on whether the condition is met
        $next_actions = $condition_met ? ( $action['children']['action_true'] ?? array() ) : ( $action['children']['action_false'] ?? array() );

        if ( JOINOTIFY_DEV_MODE ) {
            error_log( "Condition content: " . print_r( $action_data['condition_content'], true ) );
            error_log( "Condition type: " . print_r( $condition_type, true ) );
            error_log( "Condition value: " . print_r( $condition_value, true ) );
            error_log( "Compare value: " . print_r( $compare_value, true ) );
            error_log( "Condition met: " . print_r( $condition_met, true ) );
            error_log( "Next actions: " . print_r( $next_actions, true ) );
        }

        return is_array( $next_actions ) ? $next_actions : array();
    }


    /**
     * Process scheduled actions
     * 
     * @since 1.0.0
     * @version 1.4.7
     * @param int $post_id | Workflow ID
     * @param array $payload | Payload data
     * @param array $action_data | Action data
     * @return void
     */
    public static function process_scheduled_action( $post_id, $payload, $action_data ) {
        // Start every scheduled segment with a clean stop flag.
        self::$funnel_stopped = false;

        // Never resume a workflow that is no longer published (trashed/draft/
        // deleted): a pending delay must not fire for a disabled automation.
        if ( get_post_status( $post_id ) !== 'publish' ) {
            Logger::register_log( sprintf( 'Skipping scheduled action: workflow %d is not published.', $post_id ), 'WARNING' );

            return;
        }

        $state_key = self::get_state_meta_key( $payload );
        $state = self::load_state( $post_id, $state_key );

        $delay_id = $action_data['id'] ?? null;

        // Guard against a duplicate cron fire resuming the same continuation twice.
        if ( $state_key && $delay_id && in_array( $delay_id, $state['processed_actions'], true ) ) {
            return;
        }

        // The delay node is considered processed now that its continuation resumes.
        if ( $delay_id ) {
            $state['processed_actions'][] = $delay_id;
            self::persist_state( $post_id, $state_key, $state );
        }

        // Resume with the continuation captured at schedule time. The same unified
        // walker handles further delays (reschedules) and conditions consistently.
        $next_actions = $action_data['data']['next_actions'] ?? array();

        self::run_segment( array_values( $next_actions ), $post_id, $payload, $state, $state_key );
    }


    /**
     * Send message text on WhatsApp
     *
     * @since 1.0.0
     * @version 1.4.7
     * @param array $action_data | Action data
     * @param array $payload | Payload data
     * @return void
     */
    public static function send_whatsapp_message_text( $action_data, $payload, $post_id = 0 ) {
        $sender = $action_data['sender'];
        $receiver = joinotify_prepare_receiver( $action_data['receiver'], $payload );
        $message = joinotify_prepare_message( $action_data['message'], $payload );

        // tag the dispatch origin for the message history
        Message_History::set_context( array(
            'source' => 'workflow',
            'workflow_id' => $post_id,
        ));

        // send message through the notification channel layer, over whichever
        // WhatsApp transport (Evolution or Cloud API) is currently active
        $result = Channel_Manager::dispatch( Notification_Message::from_array( array(
            'channel' => Transport::active_channel_id(),
            'type' => 'text',
            'sender' => $sender,
            'receiver' => $receiver,
            'content' => $message,
            'context' => array(
                'source' => 'workflow',
                'workflow_id' => $post_id,
            ),
        )));

        Message_History::clear_context();

        if ( ! $result->is_success() && ! Transport::is_cloud() ) {
            // refresh the stored connection state for the sender (Evolution only)
            Controller::get_connection_state( $sender );
        }

        if ( defined('JOINOTIFY_DEBUG_MODE') && JOINOTIFY_DEBUG_MODE ) {
            if ( $result->is_success() ) {
                Logger::register_log( "Message sent successfully to: $receiver" );
            } else {
                Logger::register_log( "Failed to send message. Response: " . print_r( $result->to_array(), true ), 'ERROR' );
            }
        }
    }


    /**
     * Executes a WhatsApp message action
     *
     * @since 1.0.0
     * @version 1.4.7
     * @param array $action_data | Action data
     * @param array $payload | Payload data
     * @return void
     */
    public static function send_whatsapp_message_media( $action_data, $payload, $post_id = 0 ) {
        $sender = $action_data['sender'];
        $receiver = joinotify_prepare_receiver( $action_data['receiver'], $payload );
        $media_type = $action_data['media_type'];
        // resolve placeholders in the media URL too, so tokens (loop item, order data,
        // AI variables) work when the file is provided as a URL instead of an attachment
        $media = joinotify_prepare_message( $action_data['media_url'] ?? '', $payload );
        $caption = joinotify_prepare_message( $action_data['caption'] ?? '', $payload );
        $attachments = Attachments::resolve( $action_data['attachments'] ?? array(), $payload );

        // tag the dispatch origin for the message history
        Message_History::set_context( array(
            'source' => 'workflow',
            'workflow_id' => $post_id,
        ));

        // Each attachment travels as its own WhatsApp message, because the API carries one
        // file per request. The caption rides on the first one only, so the customer does
        // not read the same text once per file.
        if ( ! empty( $attachments ) ) {
            $result = self::send_whatsapp_attachments( $sender, $receiver, $media_type, $caption, $attachments, $post_id );

            Message_History::clear_context();

            if ( defined('JOINOTIFY_DEBUG_MODE') && JOINOTIFY_DEBUG_MODE ) {
                if ( $result && $result->is_success() ) {
                    Logger::register_log( sprintf( 'WhatsApp attachments sent successfully to: %s', $receiver ) );
                } else {
                    Logger::register_log( sprintf( 'Failed to send WhatsApp attachments to: %s. Response: %s', $receiver, $result ? print_r( $result->to_array(), true ) : 'no file could be resolved' ), 'ERROR' );
                }
            }

            return;
        }

        // send message through the notification channel layer, over whichever
        // WhatsApp transport (Evolution or Cloud API) is currently active
        $result = Channel_Manager::dispatch( Notification_Message::from_array( array(
            'channel' => Transport::active_channel_id(),
            'type' => ( 'audio' === $media_type ) ? 'audio' : 'media',
            'sender' => $sender,
            'receiver' => $receiver,
            'media_type' => $media_type,
            'media_url' => $media,
            'caption' => $caption,
            'context' => array(
                'source' => 'workflow',
                'workflow_id' => $post_id,
            ),
        )));

        Message_History::clear_context();

        if ( ! $result->is_success() && ! Transport::is_cloud() ) {
            // refresh the stored connection state for the sender (Evolution only)
            Controller::get_connection_state( $sender );
        }

        if ( defined('JOINOTIFY_DEBUG_MODE') && JOINOTIFY_DEBUG_MODE ) {
            if ( $result->is_success() ) {
                Logger::register_log( "Message sent successfully to: $receiver" );
            } else {
                Logger::register_log( "Failed to send message. Response: " . print_r( $result->to_array(), true ), 'ERROR' );
            }
        }
    }


    /**
     * Deliver each resolved attachment as its own WhatsApp media message.
     *
     * A protected WooCommerce download has no publicly reachable URL, so a local file is
     * embedded as base64 rather than handed to the API as a link. That also keeps the
     * customer's download counter untouched, which fetching a permission link would spend.
     *
     * @since 2.1.0
     * @param string $sender | Sender phone number
     * @param string $receiver | Recipient phone number
     * @param string $media_type | Media type configured on the action
     * @param string $caption | Caption resolved from the action
     * @param array $attachments | Resolved attachment files
     * @param int $post_id | Workflow post ID
     * @return \MeuMouse\Joinotify\Notifications\Channel_Result|null Result of the last dispatch
     */
    protected static function send_whatsapp_attachments( $sender, $receiver, $media_type, $caption, $attachments, $post_id = 0 ) {
        $result = null;
        $first = true;

        /**
         * Filter the maximum size of a single WhatsApp attachment
         *
         * @since 2.1.0
         * @param int $limit | Size in bytes
         */
        $limit = (int) apply_filters( 'Joinotify/Workflow_Processor/Whatsapp_Attachment_Size_Limit', 16 * MB_IN_BYTES );

        foreach ( $attachments as $file ) {
            $name = (string) ( $file['name'] ?? '' );
            $media = '';

            if ( ! empty( $file['remote'] ) && ! empty( $file['url'] ) ) {
                $media = (string) $file['url'];
            } else {
                $size = absint( $file['size'] ?? 0 );

                if ( $size > 0 && $size > $limit ) {
                    Logger::register_log( sprintf( 'Joinotify: WhatsApp attachment %s exceeds the size limit and was not sent.', $name ), 'WARNING' );

                    continue;
                }

                $contents = Attachments::get_contents( $file );

                if ( false === $contents ) {
                    continue;
                }

                $media = base64_encode( $contents );
            }

            if ( '' === $media ) {
                continue;
            }

            $result = Channel_Manager::dispatch( Notification_Message::from_array( array(
                'channel' => Transport::active_channel_id(),
                'type' => 'media',
                'sender' => $sender,
                'receiver' => $receiver,
                'media_type' => self::resolve_whatsapp_media_type( $file, $media_type ),
                'media_url' => $media,
                // only the first message carries the caption, so the text is not repeated
                'caption' => $first ? $caption : '',
                'meta' => array(
                    'file_name' => $name,
                ),
                'context' => array(
                    'source' => 'workflow',
                    'workflow_id' => $post_id,
                ),
            )));

            $first = false;
        }

        return $result;
    }


    /**
     * Pick the WhatsApp media type of a resolved attachment.
     *
     * The action setting describes the message as a whole, but a mixed attachment list can
     * hold an image next to a PDF, so the file mime decides whenever it is conclusive.
     *
     * @since 2.1.0
     * @param array $file | Resolved attachment file
     * @param string $fallback | Media type configured on the action
     * @return string
     */
    protected static function resolve_whatsapp_media_type( $file, $fallback ) {
        $mime = (string) ( $file['mime'] ?? '' );

        if ( 0 === strpos( $mime, 'image/' ) ) {
            return 'image';
        }

        if ( 0 === strpos( $mime, 'video/' ) ) {
            return 'video';
        }

        if ( 0 === strpos( $mime, 'audio/' ) ) {
            return 'audio';
        }

        // audio is a separate transport on the action, so it never describes an attachment
        return ( '' !== $fallback && 'audio' !== $fallback ) ? $fallback : 'document';
    }


    /**
     * Send a text message on Telegram.
     *
     * The chat id (receiver) and message support placeholders. The chat id is
     * resolved with the generic placeholder resolver — not joinotify_prepare_receiver,
     * which strips non-digits and would corrupt negative group ids / @usernames.
     *
     * @since 2.1.0
     * @param array $action_data | Action data
     * @param array $payload | Payload data
     * @param int $post_id | Workflow post ID
     * @return void
     */
    public static function send_telegram_message_text( $action_data, $payload, $post_id = 0 ) {
        $receiver = joinotify_prepare_message( $action_data['receiver'] ?? '', $payload );
        $message = joinotify_prepare_message( $action_data['message'] ?? '', $payload );

        // tag the dispatch origin for the message history
        Message_History::set_context( array(
            'source' => 'workflow',
            'workflow_id' => $post_id,
        ));

        // send message through the notification channel layer
        $result = Channel_Manager::dispatch( Notification_Message::from_array( array(
            'channel' => 'telegram',
            'type' => 'text',
            'receiver' => $receiver,
            'content' => $message,
            'context' => array(
                'source' => 'workflow',
                'workflow_id' => $post_id,
            ),
        )));

        Message_History::clear_context();

        if ( defined('JOINOTIFY_DEBUG_MODE') && JOINOTIFY_DEBUG_MODE ) {
            if ( $result->is_success() ) {
                Logger::register_log( "Telegram message sent successfully to: $receiver" );
            } else {
                Logger::register_log( "Failed to send Telegram message. Response: " . print_r( $result->to_array(), true ), 'ERROR' );
            }
        }
    }


    /**
     * Send an e-mail through Resend.
     *
     * Recipient, subject and body support placeholders. The recipient is resolved
     * with the generic placeholder resolver (not joinotify_prepare_receiver, which
     * is phone-oriented). The subject travels in the message meta bag.
     *
     * @since 2.1.0
     * @param array $action_data | Action data
     * @param array $payload | Payload data
     * @param int $post_id | Workflow post ID
     * @return void
     */
    public static function send_resend_email( $action_data, $payload, $post_id = 0 ) {
        $receiver = joinotify_prepare_message( $action_data['receiver'] ?? '', $payload );
        $subject = joinotify_prepare_message( $action_data['subject'] ?? '', $payload );
        $message = joinotify_prepare_message( $action_data['message'] ?? '', $payload );
        $attachments = Attachments::resolve( $action_data['attachments'] ?? array(), $payload );

        // tag the dispatch origin for the message history
        Message_History::set_context( array(
            'source' => 'workflow',
            'workflow_id' => $post_id,
        ));

        // send message through the notification channel layer
        $result = Channel_Manager::dispatch( Notification_Message::from_array( array(
            'channel' => 'resend',
            'type' => 'text',
            'receiver' => $receiver,
            'content' => $message,
            'attachments' => $attachments,
            'meta' => array(
                'subject' => $subject,
            ),
            'context' => array(
                'source' => 'workflow',
                'workflow_id' => $post_id,
            ),
        )));

        Message_History::clear_context();

        if ( defined('JOINOTIFY_DEBUG_MODE') && JOINOTIFY_DEBUG_MODE ) {
            if ( $result->is_success() ) {
                Logger::register_log( "Resend e-mail sent successfully to: $receiver" );
            } else {
                Logger::register_log( "Failed to send Resend e-mail. Response: " . print_r( $result->to_array(), true ), 'ERROR' );
            }
        }
    }


    /**
     * Generate a message with AI at trigger time and send it via WhatsApp.
     *
     * The prompt and system message support placeholders, so the trigger
     * context (customer name, order data, etc.) is injected before generation.
     *
     * @since 2.0.0
     * @param array $action_data | Action data
     * @param array $payload | Payload data
     * @param int $post_id | Workflow post ID
     * @return void
     */
    public static function send_whatsapp_ai_message( $action_data, $payload, $post_id = 0 ) {
        $sender = $action_data['sender'] ?? '';
        $receiver = joinotify_prepare_receiver( $action_data['receiver'] ?? '', $payload );

        // resolve placeholders so the trigger context is injected into the prompt
        $prompt = joinotify_prepare_message( $action_data['ai_prompt'] ?? '', $payload );
        $system = self::build_ai_system_message( $action_data, $payload );

        if ( '' === trim( $prompt ) ) {
            Logger::register_log( 'Skipping AI WhatsApp message: empty prompt.', 'WARNING' );

            return;
        }

        $temperature = isset( $action_data['ai_temperature'] ) && is_numeric( $action_data['ai_temperature'] )
            ? (float) $action_data['ai_temperature']
            : null;

        // generate the message text with the active AI provider
        $ai_response = AI_Manager::generate( new AI_Request( array(
            'system' => $system,
            'prompt' => $prompt,
            'provider' => $action_data['ai_provider'] ?? '',
            'model' => $action_data['ai_model'] ?? '',
            'temperature' => $temperature,
            'context' => array(
                'intent' => 'whatsapp_message',
                'workflow_id' => $post_id,
            ),
        )));

        if ( ! $ai_response->is_successful() ) {
            $error = $ai_response->get_error();
            $error_message = $error ? $error->get_error_message() : 'unknown error';

            Logger::register_log( "AI WhatsApp message generation failed: $error_message", 'ERROR' );

            return;
        }

        $message = $ai_response->get_text();

        // tag the dispatch origin for the message history
        Message_History::set_context( array(
            'source' => 'workflow',
            'workflow_id' => $post_id,
        ));

        // send the generated message over the active WhatsApp transport
        $response = Transport::send_message_text( $sender, $receiver, $message );

        Message_History::clear_context();

        if ( 201 !== $response && ! Transport::is_cloud() ) {
            // refresh the stored connection state for the sender (Evolution only)
            Controller::get_connection_state( $sender );
        }

        if ( defined('JOINOTIFY_DEBUG_MODE') && JOINOTIFY_DEBUG_MODE ) {
            if ( 201 === $response ) {
                Logger::register_log( "AI message sent successfully to: $receiver" );
            } else {
                Logger::register_log( "Failed to send AI message. Response: " . print_r( $response, true ), 'ERROR' );
            }
        }
    }


    /**
     * Build the system message for an AI message action.
     *
     * Combines the node's system instructions (with placeholders resolved) and
     * the tone/length directives selected on the node.
     *
     * @since 2.0.0
     * @param array $action_data | Action data
     * @param array $payload | Payload data
     * @return string
     */
    protected static function build_ai_system_message( $action_data, $payload ) {
        $system = joinotify_prepare_message( $action_data['ai_system'] ?? '', $payload );

        $tone_map = array(
            'formal' => __( 'Use a formal and professional tone.', 'joinotify' ),
            'casual' => __( 'Use a casual and relaxed tone.', 'joinotify' ),
            'friendly' => __( 'Use a warm and friendly tone.', 'joinotify' ),
        );

        $length_map = array(
            'short' => __( 'Keep the message very short, one or two sentences.', 'joinotify' ),
            'medium' => __( 'Keep the message concise, around two to four sentences.', 'joinotify' ),
            'long' => __( 'You may write a longer, detailed message.', 'joinotify' ),
        );

        $tone = isset( $action_data['ai_tone'] ) ? sanitize_key( (string) $action_data['ai_tone'] ) : '';
        $length = isset( $action_data['ai_length'] ) ? sanitize_key( (string) $action_data['ai_length'] ) : '';

        $directives = array();

        if ( isset( $tone_map[ $tone ] ) ) {
            $directives[] = $tone_map[ $tone ];
        }

        if ( isset( $length_map[ $length ] ) ) {
            $directives[] = $length_map[ $length ];
        }

        // always produce plain WhatsApp-ready text
        $directives[] = __( 'Write a WhatsApp message in plain text. Reply with the message content only, without any preamble.', 'joinotify' );

        $parts = array_filter( array_merge( array( $system ), $directives ), static function( $part ) {
            return '' !== trim( (string) $part );
        });

        return implode( "\n\n", $parts );
    }


    /**
     * Execute a PHP snippet from a workflow action
     *
     * @since 1.1.0
     * @param string $snippet_php | PHP Code to execute
     * @param array $payload | Payload data
     * @return bool Returns true if executed successfully
     */
    public static function execute_snippet_php( $snippet_php, $payload ) {
        if ( empty( $snippet_php ) ) {
            Logger::register_log( 'Empty PHP snippet, skipping execution.', 'WARNING' );

            return false;
        }

        /**
         * Master switch to allow/deny PHP snippet execution.
         *
         * Returning false here disables the eval()-based snippet action entirely,
         * letting security-conscious sites turn it off without code changes.
         *
         * @since 2.0.0
         * @param bool   $allow       Whether snippet execution is allowed.
         * @param string $snippet_php The snippet source.
         * @param array  $payload     Runtime payload.
         */
        if ( ! apply_filters( 'Joinotify/Snippet/Allow_Execution', true, $snippet_php, $payload ) ) {
            Logger::register_log( 'PHP snippet execution is disabled by filter.', 'WARNING' );

            return false;
        }

        // remove the `<?php` tag if it exists
        $snippet_php = preg_replace( '/^\s*<\?php\s*/', '', $snippet_php );

        /**
         * Dangerous functions blocked inside snippets (command execution, file I/O,
         * network sockets, dynamic invocation and code-eval vectors). The previous
         * list only blocked a handful and was trivially bypassable (e.g. fopen,
         * call_user_func, include were allowed).
         *
         * @since 2.0.0
         * @param array $blocked Function names to block.
         */
        $blocked_functions = apply_filters( 'Joinotify/Snippet/Blocked_Functions', array(
            // command execution
            'exec', 'shell_exec', 'system', 'passthru', 'proc_open', 'popen', 'proc_nice', 'pcntl_exec',
            // code evaluation / dynamic definition
            'eval', 'assert', 'create_function',
            // dynamic invocation (blocklist-bypass vectors)
            'call_user_func', 'call_user_func_array',
            // environment / module loading
            'dl', 'putenv',
            // filesystem
            'file_get_contents', 'file_put_contents', 'fopen', 'fwrite', 'fputs', 'fread',
            'unlink', 'rename', 'copy', 'rmdir', 'mkdir', 'chmod', 'chown', 'symlink', 'link',
            // network
            'fsockopen', 'pfsockopen', 'stream_socket_client', 'curl_exec', 'curl_multi_exec',
        ) );

        foreach ( $blocked_functions as $function ) {
            // match `name(` even with whitespace, ignoring case
            if ( preg_match( '/\b' . preg_quote( $function, '/' ) . '\s*\(/i', $snippet_php ) ) {
                Logger::register_log( "Attempt to execute blocked function: $function", 'ERROR' );

                return false;
            }
        }

        // block include/require language constructs (with or without parentheses)
        if ( preg_match( '/\b(include|require)(_once)?\b/i', $snippet_php ) ) {
            Logger::register_log( 'Attempt to use include/require in a PHP snippet.', 'ERROR' );

            return false;
        }

        // block backtick shell execution
        if ( strpos( $snippet_php, '`' ) !== false ) {
            Logger::register_log( 'Attempt to use shell execution (backticks) in a PHP snippet.', 'ERROR' );

            return false;
        }

        // block variable / dynamic function calls like $fn(...) which bypass the blocklist
        if ( preg_match( '/\$\w+\s*\(/', $snippet_php ) ) {
            Logger::register_log( 'Attempt to use a variable function call in a PHP snippet.', 'ERROR' );

            return false;
        }

        // register log before execution for debugging
        if ( defined('JOINOTIFY_DEBUG_MODE') && JOINOTIFY_DEBUG_MODE ) {
            Logger::register_log( "Running PHP Snippet: \n" . $snippet_php );
        }

        try {
            // create a safe execution environment
            ob_start();

            // execute the snippet
            eval( $snippet_php ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.eval
            
            // get the output buffer contents
            $output = ob_get_clean();

            // result execution log
            if ( defined('JOINOTIFY_DEBUG_MODE') && JOINOTIFY_DEBUG_MODE ) {
                Logger::register_log( "PHP Snippet result: \n" . print_r( $output, true ) );
            }

            return true;
        } catch ( \Throwable $e ) {
            Logger::register_log( "Error executing PHP snippet: " . $e->getMessage(), 'ERROR' );

            return false;
        }
    }


    /**
     * Execute create WooCommerce coupon action
     * 
     * @since 1.1.0
     * @param array $action_data | Action data
     * @param array $payload | Payload data
     * @return void
     */
    public static function execute_wc_coupon_action( $action_data, $payload, $post_id = 0 ) {
        $settings = isset( $action_data['settings'] ) && is_array( $action_data['settings'] ) ? $action_data['settings'] : array();

        $create_coupon = Woocommerce::generate_wc_coupon( $settings );

        // Bail out cleanly when the coupon could not be created (missing data,
        // duplicate code, etc.) instead of treating a WP_Error as an array.
        if ( is_wp_error( $create_coupon ) ) {
            Logger::register_log( 'Failed to create coupon: ' . $create_coupon->get_error_message(), 'ERROR' );

            return false;
        }

        // expose the generated coupon details to the message placeholders
        $payload['settings'] = $settings;
        $payload['settings']['coupon_code'] = $create_coupon['coupon_code'] ?? '';

        // The message config is stored as {sender, receiver, message} under
        // settings.message, which is exactly the shape send_whatsapp_message_text()
        // expects as its action_data argument.
        $message = isset( $settings['message'] ) && is_array( $settings['message'] ) ? $settings['message'] : array();

        if ( self::is_config_value_empty( $message['sender'] ?? null ) || self::is_config_value_empty( $message['receiver'] ?? null ) ) {
            Logger::register_log( 'Coupon created but notification skipped: missing sender/receiver.', 'WARNING' );

            return true;
        }

        // pass the workflow post ID so the dispatch is tagged in the message history
        self::send_whatsapp_message_text( $message, $payload, $post_id );

        if ( defined('JOINOTIFY_DEBUG_MODE') && JOINOTIFY_DEBUG_MODE ) {
            $coupon_id = (int) ( $create_coupon['coupon_id'] ?? 0 );

            Logger::register_log( $coupon_id > 0 ? 'Coupon created successfully.' : 'Failed to create coupon.', $coupon_id > 0 ? 'INFO' : 'ERROR' );
        }

        return true;
    }


    /**
     * Execute the AI smart variable action.
     *
     * Generates a named value from a system message + prompt and stores it on
     * the payload under "ai_vars" (by reference), so later actions can reference
     * it with the {{ ai:NAME }} placeholder. The value travels with the payload,
     * so it survives time delays (the payload is serialized into the cron event).
     *
     * @since 2.0.0
     * @param array $action_data | Action data
     * @param array $payload | Payload data (by reference)
     * @return bool
     */
    public static function execute_dynamic_placeholder( $action_data, &$payload ) {
        $name = isset( $action_data['var_name'] ) ? sanitize_key( (string) $action_data['var_name'] ) : '';

        if ( '' === $name ) {
            Logger::register_log( 'Skipping AI variable: missing variable name.', 'WARNING' );

            return false;
        }

        $prompt = joinotify_prepare_message( $action_data['ai_prompt'] ?? '', $payload );
        $system = joinotify_prepare_message( $action_data['ai_system'] ?? '', $payload );

        if ( '' === trim( $prompt ) ) {
            Logger::register_log( "Skipping AI variable {$name}: empty prompt.", 'WARNING' );

            return false;
        }

        $temperature = isset( $action_data['ai_temperature'] ) && is_numeric( $action_data['ai_temperature'] )
            ? (float) $action_data['ai_temperature']
            : null;

        $response = AI_Manager::generate( new AI_Request( array(
            'system' => $system,
            'prompt' => $prompt,
            'provider' => $action_data['ai_provider'] ?? '',
            'model' => $action_data['ai_model'] ?? '',
            'temperature' => $temperature,
            'context' => array(
                'intent' => 'smart_variable',
                'variable' => $name,
            ),
        )));

        if ( ! $response->is_successful() ) {
            $error = $response->get_error();

            Logger::register_log(
                "AI variable {$name} generation failed: " . ( $error ? $error->get_error_message() : 'unknown error' ),
                'ERROR'
            );

            return false;
        }

        if ( ! isset( $payload['ai_vars'] ) || ! is_array( $payload['ai_vars'] ) ) {
            $payload['ai_vars'] = array();
        }

        $payload['ai_vars'][ $name ] = $response->get_text();

        return true;
    }
}
