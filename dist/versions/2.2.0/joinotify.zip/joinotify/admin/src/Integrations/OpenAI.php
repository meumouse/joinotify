<?php

namespace MeuMouse\Joinotify\Integrations;

use MeuMouse\Joinotify\AI\Providers\OpenAI_Provider;

// Exit if accessed directly.
defined('ABSPATH') || exit;

/**
 * Add integration with OpenAI
 *
 * @since 1.3.0
 * @version 2.0.0
 * @package MeuMouse\Joinotify\Integrations
 * @author MeuMouse.com
 */
class OpenAI extends Integrations_Base {

    /**
     * Construct function
     *
     * @since 1.3.0
     * @version 2.0.0
     * @return void
     */
    public function __construct() {
        // add integration on settings
        add_filter( 'Joinotify/Settings/Tabs/Integrations', array( $this, 'add_integration_item' ), 40, 1 );
    }


    /**
     * Add integration item on settings
     *
     * @since 1.3.0
     * @version 2.0.0
     * @param array $integrations | Current integrations
     * @return array
     */
    public function add_integration_item( $integrations ) {
        $integrations['open_ai'] = self::build_integration_item(
            'open_ai',
            esc_html__( 'OpenAI', 'joinotify' ),
            esc_html__( 'Create dynamic messages for your automations in a simple and direct way using ChatGPT.', 'joinotify' ),
            '<svg fill="#000000" viewBox="0 0 24 24" role="img" xmlns="http://www.w3.org/2000/svg" style="max-width: 4.5rem;"><g stroke-width="0"></g><g stroke-linecap="round" stroke-linejoin="round"></g><g><title>OpenAI icon</title><path d="M22.2819 9.8211a5.9847 5.9847 0 0 0-.5157-4.9108 6.0462 6.0462 0 0 0-6.5098-2.9A6.0651 6.0651 0 0 0 4.9807 4.1818a5.9847 5.9847 0 0 0-3.9977 2.9 6.0462 6.0462 0 0 0 .7427 7.0966 5.98 5.98 0 0 0 .511 4.9107 6.051 6.051 0 0 0 6.5146 2.9001A5.9847 5.9847 0 0 0 13.2599 24a6.0557 6.0557 0 0 0 5.7718-4.2058 5.9894 5.9894 0 0 0 3.9977-2.9001 6.0557 6.0557 0 0 0-.7475-7.0729zm-9.022 12.6081a4.4755 4.4755 0 0 1-2.8764-1.0408l.1419-.0804 4.7783-2.7582a.7948.7948 0 0 0 .3927-.6813v-6.7369l2.02 1.1686a.071.071 0 0 1 .038.052v5.5826a4.504 4.504 0 0 1-4.4945 4.4944zm-9.6607-4.1254a4.4708 4.4708 0 0 1-.5346-3.0137l.142.0852 4.783 2.7582a.7712.7712 0 0 0 .7806 0l5.8428-3.3685v2.3324a.0804.0804 0 0 1-.0332.0615L9.74 19.9502a4.4992 4.4992 0 0 1-6.1408-1.6464zM2.3408 7.8956a4.485 4.485 0 0 1 2.3655-1.9728V11.6a.7664.7664 0 0 0 .3879.6765l5.8144 3.3543-2.0201 1.1685a.0757.0757 0 0 1-.071 0l-4.8303-2.7865A4.504 4.504 0 0 1 2.3408 7.872zm16.5963 3.8558L13.1038 8.364 15.1192 7.2a.0757.0757 0 0 1 .071 0l4.8303 2.7913a4.4944 4.4944 0 0 1-.6765 8.1042v-5.6772a.79.79 0 0 0-.407-.667zm2.0107-3.0231l-.142-.0852-4.7735-2.7818a.7759.7759 0 0 0-.7854 0L9.409 9.2297V6.8974a.0662.0662 0 0 1 .0284-.0615l4.8303-2.7866a4.4992 4.4992 0 0 1 6.6802 4.66zM8.3065 12.863l-2.02-1.1638a.0804.0804 0 0 1-.038-.0567V6.0742a4.4992 4.4992 0 0 1 7.3757-3.4537l-.142.0805L8.704 5.459a.7948.7948 0 0 0-.3927.6813zm1.0976-2.3654l2.602-1.4998 2.6069 1.4998v2.9994l-2.5974 1.4997-2.6067-1.4997Z"></path></g></svg>',
            array(
                'category' => 'ai',
                'setting_key' => 'enable_openai_integration',
                'action_hook' => 'Joinotify/Settings/Tabs/Integrations/OpenAI',
                'settings' => self::get_integration_settings(),
                'modal' => array(
                    'title' => __( 'Artificial Intelligence settings', 'joinotify' ),
                    'description' => __( 'Configure the AI provider, credentials, and the default behavior used to generate messages.', 'joinotify' ),
                    'button_label' => __( 'Configure', 'joinotify' ),
                ),
            )
        );

        return $integrations;
    }


    /**
     * Declarative settings rendered in the integration modal.
     *
     * @since 2.0.0
     * @return array<int,array<string,mixed>>
     */
    public static function get_integration_settings() {
        $openai_models = ( new OpenAI_Provider() )->get_models();

        return array(
            self::field_text(
                'openai_api_key',
                esc_html__( 'OpenAI API key', 'joinotify' ),
                esc_html__( 'Secret key used to authenticate requests to OpenAI. Find it at platform.openai.com.', 'joinotify' ),
                array(
                    'placeholder' => 'sk-...',
                    'autocomplete' => 'off',
                )
            ),
            self::field_select(
                'openai_default_model',
                esc_html__( 'Default model', 'joinotify' ),
                esc_html__( 'Model used when a workflow node does not override it. The list is fetched from OpenAI and can be refreshed.', 'joinotify' ),
                $openai_models,
                array(
                    'default' => 'gpt-4o-mini',
                    'component' => 'openai-model-select',
                )
            ),
            self::field_text(
                'openai_default_temperature',
                esc_html__( 'Default temperature', 'joinotify' ),
                esc_html__( 'Creativity of the responses, from 0 (deterministic) to 2 (more creative).', 'joinotify' ),
                array(
                    'placeholder' => '0.7',
                    'inputmode' => 'decimal',
                    'default' => '0.7',
                )
            ),
            self::field_textarea(
                'ai_global_system_prompt',
                esc_html__( 'Global persona / system prompt', 'joinotify' ),
                esc_html__( 'Brand voice and rules inherited by every AI generation. Example: "You are the support agent for Store X, be cordial and concise.".', 'joinotify' ),
                array(
                    'placeholder' => __( 'You are a helpful assistant for my store...', 'joinotify' ),
                    'rows' => 4,
                )
            ),
        );
    }
}
