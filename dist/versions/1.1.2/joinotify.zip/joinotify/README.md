# Joinotify

Aumente a satisfação do seu cliente automatizando o envio de mensagens via WhatsApp com o Joinotify.

#### Propriedade intelectual:
O software Joinotify ® é uma propriedade registrada da MEUMOUSE.COM® – SOLUÇÕES DIGITAIS LTDA, em conformidade com o §2°, art. 2° da Lei 9.609, de 19 de Fevereiro de 1998.
É expressamente proibido a distribuição ou cópia ilegal deste software, sujeita a penalidades conforme as leis de direitos autorais vigentes.

### Instalação:

#### Instalação via painel de administração:

Você pode instalar um plugin WordPress de duas maneiras: via o painel de administração do WordPress ou via FTP. Aqui estão as etapas para ambos os métodos:

* Acesse o painel de administração do seu site WordPress.
* Vá para “Plugins” e clique em “Adicionar Novo”.
* Digite o nome do plugin que você deseja instalar na barra de pesquisa ou carregue o arquivo ZIP do plugin baixado.
* Clique em “Instalar Agora” e espere até que o plugin seja instalado.
* Clique em “Ativar Plugin”.

#### Instalação via FTP:

* Baixe o arquivo ZIP do plugin que você deseja instalar.
* Descompacte o arquivo ZIP em seu computador.
* Conecte-se ao seu servidor via FTP.
* Navegue até a pasta “wp-content/plugins”.
* Envie a pasta do plugin descompactada para a pasta “plugins” no seu servidor.
* Acesse o painel de administração do seu site WordPress.
* Vá para “Plugins” e clique em “Plugins Instalados”.
* Localize o plugin que você acabou de instalar e clique em “Ativar”.
* Após seguir essas etapas, o plugin deve estar instalado e funcionando corretamente em seu site WordPress.

### Registro de alterações (Changelogs):

Versão 1.1.2 (24/02/2024)
* Correção de bugs

Versão 1.1.1 (24/02/2024)
* Correção de bugs

Versão 1.1.0 (24/02/2024)
* Correção de bugs
* Otimizações
* Recurso adicionado: Ativar modo depuração
* Recurso adicionado: Integração com formulários do Elementor
* Recurso removido: Variáveis de texto {{ br }} e {{ phone }}
* Recurso removido: Atualização de configurações automáticas
* Recurso adicionado: Variáveis de texto {{ wc_billing_first_name }}, {{ wc_billing_last_name }}, {{ wc_billing_email }}, {{ wc_billing_phone }}, {{ wc_shipping_phone }}, {{ wc_order_status }}, {{ wc_billing_full_address }}, {{ wc_shipping_full_address }}, {{ wc_order_total }}, {{ wc_total_discount }}, {{ wc_total_tax }}, {{ wc_total_refunded }}, {{ wc_coupon_codes }}, {{ wc_payment_method_title }}, {{ wc_shipping_address }}, {{ wc_checkout_field=[FIELD_ID] }}
* Recurso adicionado: Ativar atualizações automáticas
* Recurso adicionado: Ação "Snippet PHP" no construtor de fluxos
* Recurso adicionado: Ação "Cupom de desconto " no construtor de fluxos para integração com WooCommerce
* Recurso adicionado: Obter informações de grupos do WhatsApp
* Recurso modificado: Alteração da biblioteca de emojis (Picmo -> EmojioneArea)

Versão 1.0.5 (05/12/2024)
* Correção de compatibilidade com PHP 7.4

Versão 1.0.4 (22/11/2024)
* Correção de bugs

Versão 1.0.3 (22/11/2024)
* Correção de bugs

Versão 1.0.2 (22/11/2024)
* Correção de bugs

Versão 1.0.1 (21/11/2024)
* Correção de bugs

Versão 1.0.0 (20/11/2024)
* Versão inicial