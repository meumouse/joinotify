Versão 2.1.0 (27/07/2026)
* Novo recurso: Entrega de produtos digitais do WooCommerce diretamente pelo construtor de fluxos, enviando arquivos e PDFs por e-mail ou WhatsApp
* Novo recurso: Envio de anexos nas ações de e-mail (Resend) e de mídia do WhatsApp, com campo reutilizável que aceita arquivos da biblioteca de mídia, links ou os arquivos digitais do próprio pedido
     - Anexos grandes no e-mail são substituídos automaticamente pelo link de download, garantindo o envio da mensagem
     - Envio de múltiplos arquivos na ação de mídia do WhatsApp
* Novo acionamento: "Acesso a produto digital liberado" (WooCommerce), recomendado para fluxos de entrega, pois os links de download já existem nesse momento
* Novo acionamento: "Arquivo digital baixado" (WooCommerce), disparado quando o cliente baixa um arquivo, ambos com filtro opcional por produto
* Novas variáveis do WooCommerce para produtos digitais: lista de produtos para download, nomes e links dos arquivos, links sem o nome, data de expiração, downloads restantes, link da área de downloads na conta do cliente e link de download por produto específico
* Melhoria: variáveis passam a respeitar o acionamento escolhido também no envio, evitando que variáveis sem contexto sejam preenchidas indevidamente
* Melhoria: preparação para o novo servidor de licenças, com migração automática e sem intervenção do usuário
     - O plugin passa a usar o novo servidor assim que o atual deixar de responder, mantendo a mesma chave de licença
     - Sites já ativados são migrados em segundo plano, sem travar o painel
     - Nenhuma licença é desativada quando o servidor está fora do ar ou quando há divergência de cadastro; nesses casos o plugin continua funcionando e avisa na tela de licença
     - Atualizações do plugin passam a ser entregues pelo novo servidor após a migração
* Correção de bugs
     - Ordem dos argumentos no acionamento de reembolso parcial do WooCommerce, que fazia a variável do pedido receber o identificador do reembolso
     - Licença expirada ou recusada pelo servidor continuava liberando os recursos premium por até 24 horas
     - Abrir a tela de licença podia desativar a licença do site quando a data de validade já havia passado
     - Licenças vitalícias marcadas como "Unlimited" ou "Lifetime" eram tratadas como expiradas
     - Resposta de ativação da licença podia ser reaproveitada na desativação, por compartilharem o mesmo cache

Versão 2.0.0 (02/07/2026)
* Novo construtor de fluxos: interface totalmente redesenhada em formato de canvas visual, com arrastar e soltar, conectar etapas, zoom, ajuste automático à tela e botões de desfazer/refazer
* Novo recurso: Inteligência Artificial no construtor de fluxos
     - Criação de fluxos completos automaticamente a partir de uma descrição em texto
     - Geração de mensagens dinâmicas do WhatsApp com IA
     - Geração de variáveis inteligentes com IA
     - Criação de snippets PHP com auxílio da IA
* Novo recurso: Variáveis de texto personalizadas, criadas pelo próprio usuário a partir de tipos de conteúdo e campos do site (inclui suporte a pedidos do WooCommerce)
* Novo recurso: Histórico de mensagens enviadas, com filtros e seletor de data por mês e ano
* Novo recurso: Login sem senha por código (OTP) enviado via WhatsApp, com suporte a novos canais no futuro
* Novo recurso: Exportar e importar todas as configurações do plugin em arquivo JSON
* Novo recurso: Acionamento "Solicitação de redefinição de senha", com variável do link de redefinição
* Novo editor de mensagens com formatação visual (negrito, itálico, emojis) convertida automaticamente para o padrão do WhatsApp
* Melhoria: pré-visualização de mídia diretamente na etapa de mensagem de mídia do WhatsApp
* Melhoria: variáveis de texto destacadas e clicáveis dentro dos campos, com aviso quando indisponíveis no acionamento escolhido
* Melhoria: ações sinalizam quando há configurações obrigatórias pendentes
* Melhoria: catálogo de condições mais completo, com seleção por lista e seletor de produtos nos valores
* Melhoria: agendamento de mensagens com data e hora específicas (tempo de espera), com fila e reprocessamento de notificações que falharam
* Melhoria: aba "Integrações" renomeada para "Aplicativos"
* Melhoria: verificação manual de atualização na aba "Sobre"
* Melhoria: migração automática dos fluxos das versões anteriores ao atualizar o plugin
* Otimizações de desempenho no carregamento do plugin e nas telas administrativas
* Suporte aprimorado a traduções (português, inglês e espanhol)
* Novos idiomas adicionados: Francês, Italiano, Alemão e Português de Portugal

Versão 1.4.7 (12/04/2026)
* Recurso adicionado: Fila para processamento de mensagens
* Mudança de tecnologia do frontend para Vue.js, Vite e Tailwind CSS

Versão 1.4.6 (10/02/2026)
* Otimizações
* Correção de bugs
     - Erro fatal devido a falta da classe ElementorPro\Modules\Forms\Classes\Action_Base

Versão 1.4.5 (24/01/2026)
* Correção de bugs
     - Erro fatal ao carregar página "Todos os fluxos": Call to undefined function convert_to_screen()
* Otimizações
* Recurso adicionado: WooCommerce -> Formato do endereço completo (faturamento e entrega)

Versão 1.4.4 (12/12/2025)
* Otimizações
     - Melhorias em segurança no instanciamento de classes

Versão 1.4.3 (08/12/2025)
* Correção de bugs
     - Verificar se o pedido foi pago
     - Criptografia de emojis em mensagens
     - Contagem de posts na tabela Todos os fluxos

Versão 1.4.2 (27/11/2025)
* Correção de bugs
     - Erro na validação de string com Proxy API
* Otimizações

Versão 1.4.1 (28/10/2025)
* Alteração na API de consulta de atualizações

Versão 1.4.0 (29/08/2025)
* Otimizações
* Recurso adicionado: Legenda para mensagens de mídia do WhatsApp
* Recurso adicionado Variáveis de texto {{ post_title }}, {{ post_date }}, {{ post_content }}, {{ post_link }}, {{ post_tags }}, {{ post_categories }} e {{ post_featured_image }}

Versão 1.3.7 (13/08/2025)
* Correção de bugs
     - Incapacidade de editar fluxos com plugin Academy LMS e similares

Versão 1.3.6 (11/07/2025)
* Correção de bugs
     - Prioridade e argumentos da função add_action() na classe Woo_Subscriptions informados fora do array de callback
     - Falha na verificação de status de pagamento de pedidos

Versão 1.3.5 (09/07/2025)
* Correção de bugs
     - Erro fatal ao alterar status de pedido: Uncaught Error: Class name must be a valid object or a string in /woocommerce/src/Internal/DataStores/Orders/OrdersTableDataStore.php:1524
* Recurso adicionado: Validação de status do post no acionamento "Post tem status alterado"

Versão 1.3.4 (16/06/2025)
* Correção de bugs
     - Link de recuperação do carrinho é vazio (Flexify Checkout - Recuperação de carrinhos abandonados)
* Otimizações
     - Melhorias na responsividade em desktop
* Recurso adicionado: Mostrar notificações de atualização de versão

Versão 1.3.3 (10/06/2025)
* Recurso adicionado: Receber avisos quando WhatsApp estiver desconectado
* Recurso removido: Ao entrar na etapa 1 da integração Flexify Checkout
* Recurso removido: Ao entrar na etapa 2 da integração Flexify Checkout
* Recurso removido: Ao entrar na etapa 3 da integração Flexify Checkout
* Recurso adicionado: Variáveis de texto: {{ fcrc_first_name }}, {{ fcrc_last_name }}, {{ fcrc_phone }}, {{ fcrc_email }}, {{ fcrc_cart_total }} (Flexify Checkout - Recuperação de carrinhos abandonados)
* Recurso adicionado: Acionamento: Coleta de lead via modal (Flexify Checkout - Recuperação de carrinhos abandonados)
* Recurso adicionado: Acionamento: Coleta de lead via checkout (Flexify Checkout - Recuperação de carrinhos abandonados)

Versão 1.3.2 (29/05/2025)
* Correção de bugs
     - Método set_default_options() indefinido na classe Helpers na linha 171
* Otimizações
     - Preencher o remetente ao importar um fluxo

Versão 1.3.1 (26/05/2025)
* Correção de bugs
     - Ação de Tempo de espera

Versão 1.3.0 (08/05/2025)
* Correção de bugs
* Otimizações
* Correção de segurança se remetente está registrado no site
* Mudança na API de envio de mensagens via WhatsApp

Versão 1.2.5 (24/03/2025)
* Correção de bugs
     - Correção na chamada de ganchos da integração Woo Subscriptions
* Otimizações

Versão 1.2.2 (17/03/2025)
* Correção de bugs:
     - Variáveis de texto em acionamentos para WooCommerce em modo testes não estavam sendo substituídas corretamente.
* Otimizações
* Recurso modificado: Variáveis de texto {{ wc_order_total }}, {{ wc_total_discount }}, {{ wc_total_tax }}, {{ wc_total_refunded }}, agora retornam valores com símbolo de moeda formatados.
* Recurso removido: Condição "Status do pedido" no acionamento "Novo pedido"
* Recurso adicionado: Adição de ações entre ações existentes no fluxo
* Recurso adicionado: Formatação de textos com variáveis do WhatsApp
* Recurso adicionado: Tradução para o idioma inglês (en-US)
* Recurso adicionado: Tradução para o idioma espanhol (es-ES)

Versão 1.2.0 (12/03/2025)
* Correção de bugs
* Otimizações
* Recurso adicionado: Biblioteca "giggsey/libphonenumber-for-php" para formatação e validação de telefones em formato internacional
* Recurso adicionado: Biblioteca "Selectize" para multi seleção de elementos
* Recurso removido: Variável de texto {{ post_id }}
* Recurso adicionado: Condições "Método de pagamento", "Método de entrega" e "Pedido pago"
* Recurso adicionado: Acionamentos: "Pagamento processado pelo PayPal"
* Recurso adicionado: Classe "Routines" para execução de rotinas; E adicionado rotina de verificação de conexão do telefones e atualizações
* Recurso adicionado: Variáveis de texto {{ fc_inter_pix_copia_cola }}, {{ fc_inter_pix_expiration_time }}, {{ fc_inter_bank_slip_url }} e {{ fcrc_recovery_link }}

Versão 1.1.2 (24/02/2025)
* Correção de bugs

Versão 1.1.1 (24/02/2025)
* Correção de bugs

Versão 1.1.0 (24/02/2025)
* Correção de bugs
* Otimizações
* Recurso adicionado: Ativar modo depuração
* Recurso adicionado: Integração com formulários do Elementor
* Recurso removido: Variáveis de texto {{ br }} e {{ phone }}
* Recurso removido: Atualização de configurações automáticas
* Recurso adicionado: Variáveis de texto {{ wc_billing_first_name }}, {{ wc_billing_last_name }}, {{ wc_billing_email }}, {{ wc_billing_phone }}, {{ wc_shipping_phone }}, {{ wc_order_status }}, {{ wc_billing_full_address }}, {{ wc_shipping_full_address }}, {{ wc_order_total }}, {{ wc_total_discount }}, {{ wc_total_tax }}, {{ wc_total_refunded }}, {{ wc_coupon_codes }}, {{ wc_payment_method_title }}, {{ wc_shipping_address }}, {{ wc_checkout_field=[FIELD_ID] }}
* Recurso adicionado: Ativar atualizações automáticas
* Recurso adicionado: Ação "Snippet PHP" no construtor de fluxos
* Recurso adicionado: Ação "Cupom de desconto " no construtor de fluxos para integração com WooCommerce
* Recurso adicionado: Obter informações de grupos do WhatsApp
* Recurso modificado: Alteração da biblioteca de emojis (Picmo -> EmojioneArea)

Versão 1.0.5 (05/12/2024)
* Correção de compatibilidade com PHP 7.4

Versão 1.0.4 (22/11/2024)
* Correção de bugs

Versão 1.0.3 (22/11/2024)
* Correção de bugs

Versão 1.0.2 (22/11/2024)
* Correção de bugs

Versão 1.0.1 (21/11/2024)
* Correção de bugs

Versão 1.0.0 (20/11/2024)
* Versão inicial
