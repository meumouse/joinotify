<?php

namespace MeuMouse\Joinotify\Core;

use MeuMouse\Joinotify\Builder\Core;
use MeuMouse\Joinotify\API\Controller;
use MeuMouse\Joinotify\Cron\Schedule;
use MeuMouse\Joinotify\Builder\Placeholders;
use MeuMouse\Joinotify\Core\Admin;
use MeuMouse\Joinotify\Validations\Conditions;

/**
 * Process workflow content and send messages
 * 
 * @since 1.0.0
 * @package MeuMouse.com
 */
class Workflow_Processor {

    /**
     * Construct function
     * 
     * @since 1.0.0
     * @return void
     */
    public function __construct() {
        // fire hooks if WooCommerce is active
        if ( class_exists('WooCommerce') && Admin::get_setting('enable_woocommerce_integration') === 'yes' ) {
            // on receive new order
            add_action( 'woocommerce_new_order', array( $this, 'process_workflow_on_new_order' ), 10, 2 );

            // when order is processing
            add_action( 'woocommerce_checkout_order_processed', array( $this, 'process_workflow_for_order_processed' ), 10, 2 );

            // when order is completed
            add_action( 'woocommerce_order_status_completed', array( $this, 'process_workflow_for_order_completed' ), 10, 2 );
        }
        
    /*    add_action('woocommerce_order_status_pending', [$this, 'handle_order_status_change'], 10, 1);
        add_action('woocommerce_order_status_processing', [$this, 'handle_order_status_change'], 10, 1);
        add_action('woocommerce_order_status_on_hold', [$this, 'handle_order_status_change'], 10, 1);
        add_action('woocommerce_order_status_completed', [$this, 'handle_order_status_change'], 10, 1);
        add_action('woocommerce_order_status_cancelled', [$this, 'handle_order_status_change'], 10, 1);
        add_action('woocommerce_order_status_refunded', [$this, 'handle_order_status_change'], 10, 1);
        add_action('woocommerce_order_status_failed', [$this, 'handle_order_status_change'], 10, 1);*/
    }


    /**
     * Process workflow on receive new order on WooCommerce
     * 
     * @since 1.0.0
     * @param int $order_id  | Order ID
     * @param \WC_Order $order | Order object
     * @return void
     */
    public function process_workflow_on_new_order( $order_id, $order ) {
        $workflows = self::get_workflows_by_hook('woocommerce_new_order');

        if ( empty( $workflows ) ) {
            return;
        }

        foreach ( $workflows as $workflow ) {
            $workflow_content = get_post_meta( $workflow->ID, 'joinotify_workflow_content', true );
    
            if ( ! empty( $workflow_content ) && is_array( $workflow_content ) ) {
                // Process each item in the workflow content
                foreach ( $workflow_content as $content ) {
                    $this->process_sequential_workflow_for_orders( $content, $order );
                }
            }
        }
    }


    /**
     * Process workflow when order status is processing
     * 
     * @since 1.0.0
     * @param int $order_id  | Order ID
     * @param \WC_Order $order | Order object
     * @return void
     */
    public function process_workflow_for_order_processed( $order_id, $order ) {
        $workflows = self::get_workflows_by_hook('woocommerce_checkout_order_processed');

        if ( empty( $workflows ) ) {
            return;
        }

        foreach ( $workflows as $workflow ) {
            $workflow_content = get_post_meta( $workflow->ID, 'joinotify_workflow_content', true );
    
            if ( ! empty( $workflow_content ) && is_array( $workflow_content ) ) {
                // Process each item in the workflow content
                foreach ( $workflow_content as $content ) {
                    $this->process_sequential_workflow_for_orders( $content, $order );
                }
            }
        }
    }


    /**
     * Process workflow when order status is complete
     * 
     * @since 1.0.0
     * @param int $order_id  | Order ID
     * @param \WC_Order $order | Order object
     * @return void
     */
    public function process_workflow_for_order_completed( $order_id, $order ) {
        $workflows = self::get_workflows_by_hook('woocommerce_order_status_completed');

        if ( empty( $workflows ) ) {
            return;
        }

        foreach ( $workflows as $workflow ) {
            $workflow_content = get_post_meta( $workflow->ID, 'joinotify_workflow_content', true );
    
            if ( ! empty( $workflow_content ) && is_array( $workflow_content ) ) {
                // Process each item in the workflow content
                foreach ( $workflow_content as $content ) {
                    $this->process_sequential_workflow_for_orders( $content, $order );
                }
            }
        }
    }


    /**
     * Returns published posts that have a specific hook in the content
     *
     * @since 1.0.0
     * @param string $hook_name | Name of the hook to search for
     * @return array | List of posts that have the specified hook
     */
    public static function get_workflows_by_hook( $hook_name ) {
        $args = array(
            'post_type' => 'joinotify-workflow',
            'post_status' => 'publish',
            'numberposts' => -1,
            'meta_query' => array(
                array(
                    'key' => 'joinotify_workflow_content',
                    'value' => $hook_name,
                    'compare' => 'LIKE',
                ),
            ),
        );

        // Returns the posts found
        return get_posts( $args );
    }


    /**
     * Processes stream content sequentially based on associated conditions and actions
     *
     * @since 1.0.0
     * @param array $workflow_content | Workflow content
     * @param \WC_Order $order | Order object
     * @return void
     */
    public function process_sequential_workflow_for_orders( $workflow_content, $order ) {
        if ( JOINOTIFY_DEBUG_MODE ) {
            error_log( 'workflow content on process_sequential_workflow_for_orders() : ' . print_r( $workflow_content, true ) );    
        }
        
        foreach ( $workflow_content as $content_item ) {
            if ( $workflow_content['type'] === 'action' && $workflow_content['data']['action'] === 'condition' ) {
                $get_condition = $workflow_content['data']['condition_content']['condition'] ?? '';
                $condition_type = $workflow_content['data']['condition_content']['type'] ?? '';
                $condition_value = $workflow_content['data']['condition_content']['value'] ?? '';
                $compare_value = Conditions::get_compare_value( $get_condition, $order );
                $condition_met = Conditions::check_condition( $condition_type, $condition_value, $compare_value );

                if ( JOINOTIFY_DEBUG_MODE ) {
                    error_log( 'get_condition: ' . print_r( $get_condition, true ) );
                    error_log( 'condition_type: ' . print_r( $condition_type, true ) );
                    error_log( 'condition_value: ' . print_r( $condition_value, true ) );
                    error_log( 'get_compare_value: ' . print_r( $compare_value, true ) );
                    error_log( 'check_condition: ' . print_r( $condition_met, true ) );
                    error_log( 'object order: ' . print_r( $order, true ) );
                }

                // if condition is true
                if ( $condition_met ) {
                    if ( isset( $workflow_content['children']['action_true'] ) ) {
                        $this->execute_action( $workflow_content['children']['action_true'], $order );

                        break;
                    } else {
                        error_log( "Condição não atendida e sem ação de fallback. Parando o fluxo." );

                        break; // Para o fluxo se não há ação de fallback
                    }
                } else {
                    if ( isset( $workflow_content['children']['action_false'] ) ) {
                        // Executa a ação para condição falsa
                        $this->execute_action( $workflow_content['children']['action_false'], $order );

                        break; // Para o fluxo após a execução da ação falsa
                    } else {
                        error_log( "Condição não atendida e sem ação de fallback. Parando o fluxo." );

                        break; // Para o fluxo se não há ação de fallback
                    }
                }
            }
            
            if ( isset( $workflow_content['data']['action'] ) && $workflow_content['data']['action'] === 'stop_funnel' ) {
                if ( JOINOTIFY_DEBUG_MODE ) {
                    error_log( "Ação 'stop_funnel' encontrada. Parando o fluxo." );
                }
                
                break;
            }
            
            if ( isset( $workflow_content['data']['action'] ) && $workflow_content['data']['action'] === 'send_whatsapp_message_text' ) {
                $this->execute_action( $workflow_content, $order );

                break;
            }
            
            if ( isset( $workflow_content['data']['action'] ) && $workflow_content['data']['action'] === 'send_whatsapp_message_media' ) {
                $this->execute_action( $workflow_content, $order );

                break;
            }
        }
    }


    /**
     * Executa uma ação específica do fluxo
     *
     * @since 1.0.0
     * @param array $action_data | Dados da ação
     * @param \WC_Order $order | Objeto do pedido
     * @return void
     */
    private function execute_action( $action_data, $order ) {
        if ( isset( $action_data['data']['action'] ) ) {
            switch ( $action_data['data']['action'] ) {
                case 'send_whatsapp_message_text':
                    $this->send_whatsapp_message_text( $action_data['data'], $order );

                    break;
                case 'send_whatsapp_message_media':
                    $this->send_whatsapp_message_media( $action_data['data'], $order );

                    break;
                default:
                    error_log( 'Ação desconhecida no fluxo: ' . $action_data['data']['action'] );
                    
                    break;
            }
        }
    }


    /**
     * Send message text on WhatsApp
     *
     * @since 1.0.0
     * @param array $action_data | Action data
     * @param array $params | Hook parameters
     * @return void
     */
    private function send_whatsapp_message_text( $action_data, $params ) {
        $sender = $action_data['sender'];
        $receiver = Placeholders::replace_placeholders( $action_data['receiver'], $params, 'production' );
        $message = Placeholders::replace_placeholders( $action_data['message'], $params, 'production' );

        // Remove non-numeric characters from receiver
        $receiver = preg_replace('/\D/', '', $receiver);

        // Add country code if missing
        if ( preg_match('/^\+\d{1,3}/', $receiver) === 0 ) {
            $receiver = Admin::get_setting('joinotify_default_country_code') . $receiver;
        }

        // Send message
        $response = Controller::send_message_text( $sender, $receiver, $message );

        if ( JOINOTIFY_DEBUG_MODE ) {
            if (201 === $response) {
                error_log("Message sent successfully to: $receiver");
            } else {
                error_log("Failed to send message. Response: " . print_r($response, true));
            }
        }
    }


    /**
     * Executes a WhatsApp message action
     *
     * @since 1.0.0
     * @param array $action_data | Action data
     * @param array $params | Hook parameters
     * @return void
     */
    private function send_whatsapp_message_media( $action_data, $params ) {
        $sender = $action_data['sender'];
        $media_type = $item['data']['media_type'];
        $media = $item['data']['media_url'];
        $receiver = Placeholders::replace_placeholders( $action_data['receiver'], $params, 'production' );

        // Remove non-numeric characters from receiver
        $receiver = preg_replace('/\D/', '', $receiver);

        // Add country code if missing
        if ( preg_match('/^\+\d{1,3}/', $receiver) === 0 ) {
            $receiver = Admin::get_setting('joinotify_default_country_code') . $receiver;
        }

        // Send message
        $response = Controller::send_message_media( $sender, $receiver, $media_type, $media );

        if ( JOINOTIFY_DEBUG_MODE ) {
            if (201 === $response) {
                error_log("Message sent successfully to: $receiver");
            } else {
                error_log("Failed to send message. Response: " . print_r($response, true));
            }
        }
    }
}