<?php

use MeuMouse\Joinotify\Core\Admin;
use MeuMouse\Joinotify\Validations\Country_Codes;

// Exit if accessed directly.
defined('ABSPATH') || exit; ?>

<div id="general" class="nav-content">
    <table class="form-table">
        <tbody>
            <tr>
                <th>
                    <?php esc_html_e( 'Código padrão do país', 'joinotify' ); ?>
                    <span class="joinotify-description"><?php esc_html_e( 'Selecione um país para definir o código padrão. O código padrão do país será usado quando não for possível obter o código de país do telefone.', 'joinotify' ); ?></span>
                </th>
                <td>
                    <select name="joinotify_default_country_code" id="joinotify_default_country_code" class="form-select form-select-lg">
                        <option class="joinotify-cc" value="0" data-country="0" <?php selected( Admin::get_setting('joinotify_default_country_code'), '0' ); ?>>
                            <?php esc_html_e( 'Nenhum', 'joinotify' ); ?>
                        </option>
                        
                        <?php foreach ( Country_Codes::build_country_code_select() as $country ) : ?>
                            <option class="joinotify-cc" value="<?php echo esc_attr( $country['code'] ); ?>" data-country="<?php echo esc_attr( $country['country'] ); ?>" <?php selected( Admin::get_setting('joinotify_default_country_code'), $country['code'] ); ?>>
                                <?php echo esc_html( $country['country'] . ' (+' . $country['code'] . ')' ); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </td>
            </tr>

            <tr>
                <th>
                    <?php esc_html_e( 'Ativar Proxy API', 'joinotify' ); ?>
                    <span class="joinotify-description"><?php esc_html_e( 'Ative essa opção para ativar endpoints neste site para processar requisições de API do Joinotify.', 'joinotify' ); ?></span>
                </th>
                <td>
                    <div class="form-check form-switch">
                        <input type="checkbox" class="toggle-switch" id="enable_proxy_api" name="enable_proxy_api" value="yes" <?php checked( Admin::get_setting('enable_proxy_api') === 'yes' ); ?> />
                    </div>
                </td>
            </tr>

        <!--    <tr>
                <th>
                    <?php //esc_html_e( 'Ativar acionamento avançado do construtor de fluxos', 'joinotify' ); ?>
                    <span class="joinotify-description"><?php //esc_html_e( 'Ative essa opção para liberar a criação de fluxos com acionamentos personalizados. Recomendado apenas para desenvolvedores.', 'joinotify' ); ?></span>
                </th>
                <td>
                    <div class="form-check form-switch">
                        <input type="checkbox" class="toggle-switch" id="enable_advanced_trigger" name="enable_advanced_trigger" value="yes" <?php //checked( Admin::get_setting('enable_advanced_trigger') === 'yes' ); ?> />
                    </div>
                </td>
            </tr> -->
        </tbody>
    </table>
</div>