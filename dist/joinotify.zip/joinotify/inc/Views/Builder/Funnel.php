<?php

// Exit if accessed directly.
defined('ABSPATH') || exit; ?>

<div id="joinotify_builder_funnel" class="">
    <div class="funnel-trigger-group"></div>
</div>