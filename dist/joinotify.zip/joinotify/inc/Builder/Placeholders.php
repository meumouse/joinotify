<?php

namespace MeuMouse\Joinotify\Builder;

use MeuMouse\Joinotify\Validations\Conditions;
use MeuMouse\Joinotify\Integrations\Woocommerce;

// Exit if accessed directly.
defined('ABSPATH') || exit;

/**
 * This class manages the builder placeholders
 * 
 * @since 1.0.0
 * @package MeuMouse.com
 */
class Placeholders {

    /**
     * Get placeholders list based on trigger type for WhatsApp messages
     *
     * @since 1.0.0
     * @param string $trigger Trigger type to filter placeholders
     * @return array Filtered list of placeholders based on the trigger
     */
    public static function get_placeholders_list( $trigger = '' ) {
        $placeholders = array(
            '{{ br }}' => array(
                'callback' => function() {
                    return "\n"; // New line for breaking the message
                },
                'description' => esc_html__( 'Para quebrar uma linha na mensagem de texto', 'joinotify' ),
            ),
            '{{ first_name }}' => array(
                'callback' => function( $user_data ) {
                    return isset( $user_data['first_name'] ) ? $user_data['first_name'] : '';
                },
                'description' => esc_html__( 'Para recuperar o primeiro nome do usuário', 'joinotify' ),
            ),
            '{{ last_name }}' => array(
                'callback' => function( $user_data ) {
                    return isset( $user_data['last_name'] ) ? $user_data['last_name'] : '';
                },
                'description' => esc_html__( 'Para recuperar o sobrenome do usuário', 'joinotify' ),
            ),
            '{{ phone }}' => array(
                'callback' => function( $user_data ) {
                    return isset( $user_data['phone'] ) ? $user_data['phone'] : '';
                },
                'description' => esc_html__( 'Para recuperar o telefone do usuário', 'joinotify' ),
            ),
            '{{ email }}' => array(
                'callback' => function( $user_data ) {
                    return isset( $user_data['email'] ) ? $user_data['email'] : '';
                },
                'description' => esc_html__( 'Para recuperar o e-mail do usuário', 'joinotify' ),
            ),
            '{{ site_url }}' => array(
                'callback' => function() {
                    return get_site_url();
                },
                'description' => esc_html__( 'Para recuperar a URL do site', 'joinotify' ),
            ),
            '{{ site_name }}' => array(
                'callback' => function() {
                    return get_bloginfo('name');
                },
                'description' => esc_html__( 'Para recuperar o nome do site', 'joinotify' ),
            ),
            '{{ current_date }}' => array(
                'callback' => function() {
                    $date_format = get_option('date_format'); // Get WordPress date format
                    return date( $date_format );
                },
                'description' => esc_html__( 'Para recuperar a data atual', 'joinotify' ),
            ),
            '{{ wc_order_number }}' => array(
                'callback' => function( $order_data ) {
                    return isset( $order_data['order_number'] ) ? $order_data['order_number'] : '';
                },
                'description' => esc_html__( 'Para recuperar o número do pedido do WooCommerce', 'joinotify' ),
            ),
            '{{ wc_order_status }}' => array(
                'callback' => function( $order_data ) {
                    return isset( $order_data['order_status'] ) ? $order_data['order_status'] : '';
                },
                'description' => esc_html__( 'Para recuperar o status do pedido do WooCommerce', 'joinotify' ),
            ),
            '{{ wc_purchased_items }}' => array(
                'callback' => function( $order_data ) {
                    return isset( $order_data['purchased_items'] ) ? $order_data['purchased_items'] : '';
                },
                'description' => esc_html__( 'Para recuperar os itens adquiridos no pedido', 'joinotify' ),
            ),
            '{{ wc_payment_url }}' => array(
                'callback' => function( $order_data ) {
                    return isset( $order_data['payment_url'] ) ? $order_data['payment_url'] : '';
                },
                'description' => esc_html__( 'Para recuperar a URL de pagamento do pedido', 'joinotify' ),
            ),
        );

        // Universal placeholders that are always available
        $universal_placeholders = array(
            '{{ br }}',
            '{{ site_url }}',
            '{{ site_name }}',
            '{{ current_date }}',
        );

        $allowed_placeholders = $universal_placeholders;
        $trigger_specific_placeholders = Conditions::get_conditional_placeholders();

        // merge universal placeholders with allowed placeholder by conditions
        if ( is_array( $trigger_specific_placeholders ) && ! empty( $trigger ) && is_string( $trigger ) ) {
            if ( isset( $trigger_specific_placeholders[$trigger] ) && is_array( $trigger_specific_placeholders[$trigger] ) ) {
                $allowed_placeholders = array_merge( $allowed_placeholders, $trigger_specific_placeholders[$trigger] );
            }
        }
    
        $filtered_placeholders = array_filter( $placeholders, function( $key ) use ( $allowed_placeholders ) {
            return is_string( $key ) && in_array( $key, $allowed_placeholders, true );
        }, ARRAY_FILTER_USE_KEY );
    
        return apply_filters( 'Joinotify/Builder/Placeholders_List', $filtered_placeholders, $trigger );
    }


    /**
     * Replace placeholders with actual values in the message
     *
     * @since 1.0.0
     * @param string $message | The message containing placeholders
     * @param array $data | Additional data used to replace placeholders
     * @param string $mode | Mode (sandbox or production)
     * @return string The message with placeholders replaced by actual values
     */
    public static function replace_placeholders( $message, $data = array(), $mode = 'sandbox' ) {
        $placeholders = self::get_placeholders_list();
        $user_data = array();

        // If in production mode, we get the real data, supporting WC_Order objects
        if ( $mode === 'production' ) {
            $user_data = self::get_production_data( $data );
        } else {
            // In sandbox mode, we use sample data
            if ( preg_match_all( '/{{\s*([\w_]+)\s*}}/', $message, $matches ) ) {
                foreach ( $matches[1] as $placeholder_key ) {
                    $user_data[$placeholder_key] = self::get_sandbox_placeholder_value( $placeholder_key );
                }
            }
        }
    
        // Merges user data with any additional data passed in $data
        $combined_data = is_array( $data ) ? array_merge( $user_data, $data ) : $user_data;
    
        // Replaces each placeholder with its corresponding value
        foreach ( $placeholders as $placeholder => $placeholder_data ) {
            if ( isset( $placeholder_data['callback'] ) && is_callable( $placeholder_data['callback'] ) ) {
                $replacement = call_user_func( $placeholder_data['callback'], $combined_data );
                
                if ( empty( $replacement ) && $replacement !== '0' && JOINOTIFY_DEBUG_MODE ) {
                    error_log( "Unreplaced placeholder: {$placeholder}" );
                }
                
                // if value has been finded then replace placeholder, else return same placeholder
                $message = str_replace( $placeholder, $replacement !== '' ? $replacement : $placeholder, $message );
            }
        }        
    
        return $message;
    }


    /**
     * Retrieve actual user or order data in production mode
     *
     * @since 1.0.0
     * @param array $data Contains keys such as 'order_id' to identify the data source
     * @return array User or order data used for placeholder replacement
     */
    public static function get_production_data( $data ) {
        $process_order_data = function( \WC_Order $order ) {
            return array(
                'first_name' => $order->get_billing_first_name(),
                'last_name' => $order->get_billing_last_name(),
                'phone' => $order->get_billing_phone(),
                'email' => $order->get_billing_email(),
                'full_address' => $order->get_billing_address_1() . ', ' . $order->get_billing_city(),
                'order_number' => $order->get_order_number(),
                'order_status' => wc_get_order_status_name( $order->get_status() ),
                'order_date' => $order->get_date_created()->date( get_option('date_format') . ' - ' . get_option('time_format') ),
                'purchased_items' => Woocommerce::get_purchased_items( $order ),
                'payment_url' => $order->get_checkout_payment_url(),
            );
        };
    
        // Verifica se o $data é uma instância de WC_Order diretamente
        if ( $data instanceof \WC_Order ) {
            return $process_order_data( $data );
        }
    
        // Se não for uma instância de WC_Order, utiliza o ID para obter o pedido
        if ( isset( $data['order_id'] ) && function_exists('wc_get_order') ) {
            $order = wc_get_order( $data['order_id'] );

            if ( $order ) {
                return $process_order_data( $order );
            }
        }
    
        // Se nenhum dado for encontrado, verifica se há um usuário logado
        if ( is_user_logged_in() ) {
            $current_user = wp_get_current_user();
    
            return array(
                'first_name' => $current_user->first_name,
                'last_name' => $current_user->last_name,
                'phone' => get_user_meta( $current_user->ID, 'billing_phone', true ),
                'email' => $current_user->user_email,
                'full_address' => get_user_meta( $current_user->ID, 'billing_address_1', true ) . ', ' . get_user_meta( $current_user->ID, 'billing_city', true ),
            );
        }
    
        // Retorna um array vazio se nenhum dado for encontrado
        return array();
    }


    /**
     * Retrieve placeholder values for sandbox mode
     *
     * @since 1.0.0
     * @param string $placeholder_key The placeholder key to retrieve sample data for
     * @return string Sample value for the specified placeholder
     */
    public static function get_sandbox_placeholder_value( $placeholder_key ) {
        // Define sample data for each placeholder key
        $sandbox_data = array(
            'first_name' => self::get_user_information('first_name'),
            'last_name' => self::get_user_information('last_name'),
            'phone' => self::get_user_information('phone'),
            'email' => self::get_user_information('email'),
            'full_address' => self::get_user_information('full_address'),
        );

        // Return the sample data if available, otherwise return an empty string
        return isset( $sandbox_data[ $placeholder_key ] ) ? $sandbox_data[ $placeholder_key ] : '';
    }


    /**
     * Returns logged in user information based on the given parameter
     *
     * @since 1.0.0
     * @param string $info_type | The type of information you want to get ('first_name', 'last_name', etc.)
     * @return string|null Returns the requested information or null if the user is not logged in or the information does not exist.
     */
    public static function get_user_information( $info_type ) {
        // Checks if the user is logged in
        if ( ! is_user_logged_in() ) {
            return null; // Returns null if the user is not logged in.
        }

        // Gets the logged in user object
        $current_user = wp_get_current_user();

        // Initialize the variable to store the value
        $value = null;

        switch ( $info_type ) {
            case 'first_name':
                $value = $current_user->first_name;

                break;
            case 'last_name':
                $value = $current_user->last_name;

                break;
            case 'full_name':
                $value = sprintf( '%s %s', $current_user->first_name, $current_user->last_name );

                break;
            case 'display_name':
                $value = $current_user->display_name;

                break;
            case 'user_login':
                $value = $current_user->user_login;

                break;
            case 'user_email':
                $value = $current_user->user_email;

                break;
            case 'user_nicename':
                $value = $current_user->user_nicename;

                break;
            case 'user_url':
                $value = $current_user->user_url;

                break;
            case 'phone':
                // Assuming the phone is saved as 'billing_phone' in WooCommerce
                $value = get_user_meta( $current_user->ID, 'billing_phone', true );

                break;
            case 'full_address':
                // Assuming the full address is saved as WooCommerce metadata
                $value = sprintf(
                    '%s, %s, %s, %s, %s',
                    get_user_meta( $current_user->ID, 'billing_address_1', true ),
                    get_user_meta( $current_user->ID, 'billing_address_2', true ),
                    get_user_meta( $current_user->ID, 'billing_city', true ),
                    get_user_meta( $current_user->ID, 'billing_postcode', true ),
                    get_user_meta( $current_user->ID, 'billing_country', true )
                );

                break;
            case 'user_registered':
                $value = $current_user->user_registered;

                break;
            case 'user_role':
                $roles = $current_user->roles;
                $value = ! empty( $roles ) ? implode( ', ', $roles ) : null;

                break;
            default:
                $value = null; // Returns null if the key is not recognized

                break;
        }

        return $value;
    }
}