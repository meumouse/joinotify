<?php

namespace MeuMouse\Joinotify\Cron;

use WP_Cron;

// Exit if accessed directly.
defined('ABSPATH') || exit;

/**
 * Schedule messages for a future time or date
 * 
 * @since 1.0.0
 * @package MeuMouse.com
 */
class Schedule {

    /**
     * Check if WordPress CRON is active
     * 
     * @since 1.0.0
     * @return bool
     */
    public static function is_wp_cron_active() {
        // Check if WordPress Cron is disabled
        if ( defined('DISABLE_WP_CRON') && DISABLE_WP_CRON ) {
            return false;
        }

        // Check if there are any scheduled events
        if ( wp_next_scheduled('some_scheduled_event_hook') ) {
            return true;
        }

        // As a fallback, check if there are any scheduled events in general
        $crons = _get_cron_array();

        if ( ! empty( $crons ) ) {
            return true; 
        }

        return false;
    }

    /**
     * Schedule a message for a future time or date
     * 
     * @since 1.0.0
     * @param int $post_id The ID of the post or workflow related to the schedule
     * @param string|int $time Time in seconds to wait or a future timestamp
     * @param string $hook Hook name to trigger the scheduled action
     * @param array $args Optional arguments for the action
     * @return void
     */
    public function schedule_message( $post_id, $time, $hook, $args = array() ) {
        // If the time is an integer, we assume it's a delay in seconds
        if ( is_int( $time ) ) {
            $timestamp = time() + $time;
        } else {
            // Otherwise, assume $time is a future timestamp
            $timestamp = strtotime( $time );
        }

        // Schedule the event if not already scheduled
        if ( ! wp_next_scheduled( $hook, array( $post_id, $args ) ) ) {
            wp_schedule_single_event( $timestamp, $hook, array( $post_id, $args ) );
        }
    }


    /**
     * Clear a scheduled message
     * 
     * @since 1.0.0
     * @param string $hook Hook name used in the schedule
     * @param int $post_id The ID of the post associated with the scheduled event
     * @param array $args Optional arguments for the action
     * @return void
     */
    public function clear_schedule( $hook, $post_id, $args = array() ) {
        // Get the next scheduled event timestamp for the given hook
        $timestamp = wp_next_scheduled( $hook, array( $post_id, $args ) );

        // Unschedule the event if it exists
        if ( $timestamp ) {
            wp_unschedule_event( $timestamp, $hook, array( $post_id, $args ) );
        }
    }


    /**
     * Check if a message is already scheduled
     * 
     * @since 1.0.0
     * @param string $hook Hook name used in the schedule
     * @param int $post_id The ID of the post associated with the scheduled event
     * @param array $args Optional arguments for the action
     * @return bool True if scheduled, false otherwise
     */
    public function is_scheduled( $hook, $post_id, $args = array() ) {
        return (bool) wp_next_scheduled( $hook, array( $post_id, $args ) );
    }


    public static function register_cron_job() {
        add_action( 'joinotify_send_message', array( __CLASS__, 'execute_scheduled_message' ), 10, 2);
    }

    public static function execute_scheduled_message( $action_data, $context_data ) {
        Controller::send_message( $action_data, $context_data );
    }
}