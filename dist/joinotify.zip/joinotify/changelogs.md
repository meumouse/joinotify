Versão 1.0.4 (22/11/2024)
* Correção de bugs

Versão 1.0.3 (22/11/2024)
* Correção de bugs

Versão 1.0.2 (22/11/2024)
* Correção de bugs

Versão 1.0.1 (21/11/2024)
* Correção de bugs

Versão 1.0.0 (20/11/2024)
* Versão inicial