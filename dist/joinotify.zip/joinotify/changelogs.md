Versão 1.0.0 (20/11/2024)
* Versão inicial