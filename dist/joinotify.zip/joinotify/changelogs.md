Versão 1.0.0 (10/10/2024)
* Versão inicial